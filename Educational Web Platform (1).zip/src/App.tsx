import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Home } from './components/Home';
import { Templates } from './components/Templates';
import { Designer } from './components/Designer';
import { Pricing } from './components/Pricing';
import { MyCards } from './components/MyCards';
import { About } from './components/About';
import { Contact } from './components/Contact';
import { Auth } from './components/Auth';

export type User = {
  id: string;
  email: string;
  name: string;
  company?: string;
};

export type BusinessCard = {
  id: string;
  userId: string;
  templateId: string;
  name: string;
  title: string;
  company: string;
  email: string;
  phone: string;
  website: string;
  address: string;
  customizations: {
    primaryColor: string;
    secondaryColor: string;
    fontStyle: string;
    layout: string;
  };
  createdAt: string;
  status: 'draft' | 'ordered' | 'printing' | 'shipped' | 'delivered';
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [editingCard, setEditingCard] = useState<BusinessCard | null>(null);

  useEffect(() => {
    // Load user from localStorage
    const savedUser = localStorage.getItem('businesscard_user');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('businesscard_user', JSON.stringify(user));
    setCurrentPage('home');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('businesscard_user');
    setCurrentPage('home');
  };

  const handleSelectTemplate = (templateId: string) => {
    setSelectedTemplate(templateId);
    setCurrentPage('designer');
  };

  const handleEditCard = (card: BusinessCard) => {
    setEditingCard(card);
    setCurrentPage('designer');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onNavigate={setCurrentPage} user={currentUser} />;
      case 'templates':
        return <Templates onSelectTemplate={handleSelectTemplate} onNavigate={setCurrentPage} />;
      case 'designer':
        return (
          <Designer
            templateId={selectedTemplate}
            editingCard={editingCard}
            user={currentUser}
            onNavigate={setCurrentPage}
            onSave={() => {
              setSelectedTemplate(null);
              setEditingCard(null);
              setCurrentPage('my-cards');
            }}
          />
        );
      case 'pricing':
        return <Pricing onNavigate={setCurrentPage} />;
      case 'my-cards':
        return <MyCards user={currentUser} onNavigate={setCurrentPage} onEditCard={handleEditCard} />;
      case 'about':
        return <About onNavigate={setCurrentPage} />;
      case 'contact':
        return <Contact onNavigate={setCurrentPage} />;
      case 'auth':
        return <Auth onLogin={handleLogin} onNavigate={setCurrentPage} />;
      default:
        return <Home onNavigate={setCurrentPage} user={currentUser} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        user={currentUser}
        onNavigate={setCurrentPage}
        onLogout={handleLogout}
        currentPage={currentPage}
      />
      <main>{renderPage()}</main>
    </div>
  );
}
