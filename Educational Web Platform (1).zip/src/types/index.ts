// Type definitions for ENTBridge platform

export interface User {
  id: string;
  name: string;
  email: string;
  username: string;
  isAdmin: boolean;
  createdAt: Date;
}

export interface Subject {
  id: string;
  name: string;
  isMandatory: boolean;
  category?: 'natural-sciences' | 'social-sciences' | 'creative';
  maxScore: number;
}

export interface Question {
  id: string;
  subjectId: string;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface TestResult {
  id: string;
  userId: string;
  subjectId: string;
  subjectName: string;
  score: number;
  maxScore: number;
  totalQuestions: number;
  correctAnswers: number;
  date: Date;
  answers: {
    questionId: string;
    selectedAnswer: number;
    isCorrect: boolean;
  }[];
}

export interface Homework {
  id: string;
  title: string;
  description: string;
  subjectId: string;
  dueDate: Date;
  assignedBy: string;
  submissions: Submission[];
}

export interface Submission {
  id: string;
  homeworkId: string;
  userId: string;
  userName: string;
  content: string;
  submittedAt: Date;
  grade?: number;
  feedback?: string;
}

export interface VideoLesson {
  id: string;
  title: string;
  subjectId: string;
  youtubeUrl: string;
  thumbnail: string;
  duration: string;
  description: string;
}
