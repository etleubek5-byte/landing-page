export type Template = {
  id: string;
  name: string;
  category: 'modern' | 'classic' | 'creative' | 'minimalist';
  primaryColor: string;
  secondaryColor: string;
  layout: 'standard' | 'vertical' | 'horizontal';
  description: string;
  popular?: boolean;
};

export const TEMPLATES: Template[] = [
  {
    id: 'modern-blue',
    name: 'Modern Blue',
    category: 'modern',
    primaryColor: '#3B82F6',
    secondaryColor: '#1E40AF',
    layout: 'standard',
    description: 'Clean and professional design with blue accents',
    popular: true,
  },
  {
    id: 'classic-black',
    name: 'Classic Black',
    category: 'classic',
    primaryColor: '#1F2937',
    secondaryColor: '#6B7280',
    layout: 'standard',
    description: 'Timeless black and white design',
    popular: true,
  },
  {
    id: 'creative-gradient',
    name: 'Creative Gradient',
    category: 'creative',
    primaryColor: '#8B5CF6',
    secondaryColor: '#EC4899',
    layout: 'horizontal',
    description: 'Eye-catching gradient design',
    popular: true,
  },
  {
    id: 'minimalist-white',
    name: 'Minimalist White',
    category: 'minimalist',
    primaryColor: '#FFFFFF',
    secondaryColor: '#F3F4F6',
    layout: 'standard',
    description: 'Simple and elegant minimalist design',
  },
  {
    id: 'modern-green',
    name: 'Modern Green',
    category: 'modern',
    primaryColor: '#10B981',
    secondaryColor: '#059669',
    layout: 'vertical',
    description: 'Fresh green design for eco-friendly brands',
  },
  {
    id: 'classic-navy',
    name: 'Classic Navy',
    category: 'classic',
    primaryColor: '#1E3A8A',
    secondaryColor: '#3B82F6',
    layout: 'standard',
    description: 'Professional navy design',
  },
  {
    id: 'creative-orange',
    name: 'Creative Orange',
    category: 'creative',
    primaryColor: '#F97316',
    secondaryColor: '#EA580C',
    layout: 'horizontal',
    description: 'Bold and energetic orange design',
  },
  {
    id: 'minimalist-gray',
    name: 'Minimalist Gray',
    category: 'minimalist',
    primaryColor: '#6B7280',
    secondaryColor: '#9CA3AF',
    layout: 'standard',
    description: 'Sophisticated gray minimalist design',
  },
  {
    id: 'modern-purple',
    name: 'Modern Purple',
    category: 'modern',
    primaryColor: '#7C3AED',
    secondaryColor: '#5B21B6',
    layout: 'vertical',
    description: 'Contemporary purple design',
  },
  {
    id: 'classic-brown',
    name: 'Classic Brown',
    category: 'classic',
    primaryColor: '#92400E',
    secondaryColor: '#78350F',
    layout: 'standard',
    description: 'Warm and professional brown design',
  },
  {
    id: 'creative-teal',
    name: 'Creative Teal',
    category: 'creative',
    primaryColor: '#14B8A6',
    secondaryColor: '#0D9488',
    layout: 'horizontal',
    description: 'Vibrant teal design',
  },
  {
    id: 'minimalist-beige',
    name: 'Minimalist Beige',
    category: 'minimalist',
    primaryColor: '#D6BCAB',
    secondaryColor: '#B08968',
    layout: 'standard',
    description: 'Soft beige minimalist design',
  },
];
