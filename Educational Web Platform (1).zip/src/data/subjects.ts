import { Subject } from '../App';

export const SUBJECTS: Subject[] = [
  {
    id: 'history-kz',
    name: 'History of Kazakhstan',
    nameKz: 'Қазақстан тарихы',
    type: 'mandatory',
    maxScore: 20,
  },
  {
    id: 'math-literacy',
    name: 'Mathematical Literacy',
    nameKz: 'Математикалық сауаттылық',
    type: 'mandatory',
    maxScore: 20,
  },
  {
    id: 'reading-literacy',
    name: 'Reading Literacy',
    nameKz: 'Оқу сауаттылығы',
    type: 'mandatory',
    maxScore: 20,
  },
  {
    id: 'mathematics',
    name: 'Mathematics',
    nameKz: 'Математика',
    type: 'elective',
    maxScore: 40,
  },
  {
    id: 'physics',
    name: 'Physics',
    nameKz: 'Физика',
    type: 'elective',
    maxScore: 40,
  },
  {
    id: 'chemistry',
    name: 'Chemistry',
    nameKz: 'Химия',
    type: 'elective',
    maxScore: 40,
  },
  {
    id: 'biology',
    name: 'Biology',
    nameKz: 'Биология',
    type: 'elective',
    maxScore: 40,
  },
  {
    id: 'geography',
    name: 'Geography',
    nameKz: 'География',
    type: 'elective',
    maxScore: 40,
  },
  {
    id: 'world-history',
    name: 'World History',
    nameKz: 'Дүниежүзі тарихы',
    type: 'elective',
    maxScore: 40,
  },
];

export type Question = {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
};

export const MOCK_QUESTIONS: Record<string, Question[]> = {
  'history-kz': [
    {
      id: 1,
      text: 'When did Kazakhstan gain independence?',
      options: ['1989', '1990', '1991', '1992'],
      correctAnswer: 2,
    },
    {
      id: 2,
      text: 'Who was the first president of Kazakhstan?',
      options: ['Nursultan Nazarbayev', 'Kassym-Jomart Tokayev', 'Dinmukhamed Kunayev', 'Askar Akayev'],
      correctAnswer: 0,
    },
    {
      id: 3,
      text: 'What was the capital of Kazakhstan before Astana?',
      options: ['Shymkent', 'Aktobe', 'Almaty', 'Karaganda'],
      correctAnswer: 2,
    },
    {
      id: 4,
      text: 'In what year was Astana renamed to Nur-Sultan?',
      options: ['2017', '2018', '2019', '2020'],
      correctAnswer: 2,
    },
    {
      id: 5,
      text: 'The Golden Horde was established in which century?',
      options: ['11th century', '12th century', '13th century', '14th century'],
      correctAnswer: 2,
    },
  ],
  'math-literacy': [
    {
      id: 1,
      text: 'If a book costs 2500 tenge and is discounted by 20%, what is the new price?',
      options: ['2000 tenge', '2100 tenge', '2200 tenge', '2300 tenge'],
      correctAnswer: 0,
    },
    {
      id: 2,
      text: 'What is 15% of 400?',
      options: ['50', '55', '60', '65'],
      correctAnswer: 2,
    },
    {
      id: 3,
      text: 'A car travels 240 km in 3 hours. What is its average speed?',
      options: ['70 km/h', '75 km/h', '80 km/h', '85 km/h'],
      correctAnswer: 2,
    },
    {
      id: 4,
      text: 'If 5 apples cost 750 tenge, how much do 8 apples cost?',
      options: ['1100 tenge', '1150 tenge', '1200 tenge', '1250 tenge'],
      correctAnswer: 2,
    },
    {
      id: 5,
      text: 'What is the area of a rectangle with length 12m and width 8m?',
      options: ['84 m²', '92 m²', '96 m²', '100 m²'],
      correctAnswer: 2,
    },
  ],
  'reading-literacy': [
    {
      id: 1,
      text: 'What is the main purpose of reading literacy skills?',
      options: [
        'To read quickly',
        'To understand and interpret texts',
        'To memorize information',
        'To write better essays',
      ],
      correctAnswer: 1,
    },
    {
      id: 2,
      text: 'Which of the following is an example of inference in reading?',
      options: [
        'Reading the title',
        'Understanding explicit facts',
        'Drawing conclusions from context',
        'Identifying the author',
      ],
      correctAnswer: 2,
    },
    {
      id: 3,
      text: 'What does synthesizing information mean?',
      options: [
        'Reading aloud',
        'Combining ideas from multiple sources',
        'Underlining key points',
        'Translating text',
      ],
      correctAnswer: 1,
    },
    {
      id: 4,
      text: 'What is a thesis statement?',
      options: [
        'The conclusion of a text',
        'The main argument or point',
        'A supporting detail',
        'A question posed by the author',
      ],
      correctAnswer: 1,
    },
    {
      id: 5,
      text: 'Which strategy helps improve reading comprehension?',
      options: [
        'Reading as fast as possible',
        'Skipping difficult words',
        'Asking questions while reading',
        'Reading only once',
      ],
      correctAnswer: 2,
    },
  ],
  mathematics: [
    {
      id: 1,
      text: 'Solve: 3x + 7 = 22',
      options: ['x = 3', 'x = 4', 'x = 5', 'x = 6'],
      correctAnswer: 2,
    },
    {
      id: 2,
      text: 'What is the derivative of x²?',
      options: ['x', '2x', 'x²', '2'],
      correctAnswer: 1,
    },
    {
      id: 3,
      text: 'Simplify: (x² - 9) / (x - 3)',
      options: ['x - 3', 'x + 3', 'x² + 3', 'x² - 3'],
      correctAnswer: 1,
    },
    {
      id: 4,
      text: 'What is sin(30°)?',
      options: ['0', '0.5', '0.707', '1'],
      correctAnswer: 1,
    },
    {
      id: 5,
      text: 'Solve: 2ˣ = 16',
      options: ['x = 2', 'x = 3', 'x = 4', 'x = 8'],
      correctAnswer: 2,
    },
  ],
  physics: [
    {
      id: 1,
      text: 'What is the SI unit of force?',
      options: ['Joule', 'Newton', 'Watt', 'Pascal'],
      correctAnswer: 1,
    },
    {
      id: 2,
      text: "What is Newton's second law?",
      options: ['F = ma', 'E = mc²', 'P = mv', 'W = Fd'],
      correctAnswer: 0,
    },
    {
      id: 3,
      text: 'What is the speed of light in vacuum?',
      options: ['3 × 10⁶ m/s', '3 × 10⁷ m/s', '3 × 10⁸ m/s', '3 × 10⁹ m/s'],
      correctAnswer: 2,
    },
    {
      id: 4,
      text: 'What type of energy is stored in a compressed spring?',
      options: ['Kinetic', 'Potential', 'Thermal', 'Chemical'],
      correctAnswer: 1,
    },
    {
      id: 5,
      text: 'What is the formula for kinetic energy?',
      options: ['mgh', '½mv²', 'mc²', 'Fd'],
      correctAnswer: 1,
    },
  ],
  chemistry: [
    {
      id: 1,
      text: 'What is the chemical symbol for gold?',
      options: ['Go', 'Gd', 'Au', 'Ag'],
      correctAnswer: 2,
    },
    {
      id: 2,
      text: 'What is the pH of a neutral solution?',
      options: ['0', '7', '10', '14'],
      correctAnswer: 1,
    },
    {
      id: 3,
      text: 'How many electrons does a carbon atom have?',
      options: ['4', '6', '8', '12'],
      correctAnswer: 1,
    },
    {
      id: 4,
      text: 'What type of bond involves sharing electrons?',
      options: ['Ionic', 'Covalent', 'Metallic', 'Hydrogen'],
      correctAnswer: 1,
    },
    {
      id: 5,
      text: 'What is the most abundant gas in Earth\'s atmosphere?',
      options: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Argon'],
      correctAnswer: 2,
    },
  ],
  biology: [
    {
      id: 1,
      text: 'What is the powerhouse of the cell?',
      options: ['Nucleus', 'Ribosome', 'Mitochondria', 'Chloroplast'],
      correctAnswer: 2,
    },
    {
      id: 2,
      text: 'What is the process by which plants make food?',
      options: ['Respiration', 'Photosynthesis', 'Digestion', 'Fermentation'],
      correctAnswer: 1,
    },
    {
      id: 3,
      text: 'What is DNA an abbreviation for?',
      options: [
        'Deoxyribonucleic Acid',
        'Dinitrogen Acid',
        'Dynamic Nuclear Acid',
        'Dual Nitrogen Amino',
      ],
      correctAnswer: 0,
    },
    {
      id: 4,
      text: 'How many chambers does the human heart have?',
      options: ['2', '3', '4', '5'],
      correctAnswer: 2,
    },
    {
      id: 5,
      text: 'What is the largest organ in the human body?',
      options: ['Liver', 'Brain', 'Heart', 'Skin'],
      correctAnswer: 3,
    },
  ],
  geography: [
    {
      id: 1,
      text: 'What is the largest country in the world by area?',
      options: ['Canada', 'China', 'Russia', 'United States'],
      correctAnswer: 2,
    },
    {
      id: 2,
      text: 'Which river is the longest in the world?',
      options: ['Amazon', 'Nile', 'Yangtze', 'Mississippi'],
      correctAnswer: 1,
    },
    {
      id: 3,
      text: 'What is the capital of Kazakhstan?',
      options: ['Almaty', 'Astana', 'Shymkent', 'Aktobe'],
      correctAnswer: 1,
    },
    {
      id: 4,
      text: 'Which ocean is the largest?',
      options: ['Atlantic', 'Indian', 'Pacific', 'Arctic'],
      correctAnswer: 2,
    },
    {
      id: 5,
      text: 'What is the highest mountain in the world?',
      options: ['K2', 'Kangchenjunga', 'Mount Everest', 'Lhotse'],
      correctAnswer: 2,
    },
  ],
  'world-history': [
    {
      id: 1,
      text: 'In what year did World War I begin?',
      options: ['1912', '1914', '1916', '1918'],
      correctAnswer: 1,
    },
    {
      id: 2,
      text: 'Who was the first emperor of Rome?',
      options: ['Julius Caesar', 'Augustus', 'Nero', 'Constantine'],
      correctAnswer: 1,
    },
    {
      id: 3,
      text: 'What year did the French Revolution begin?',
      options: ['1776', '1789', '1799', '1804'],
      correctAnswer: 1,
    },
    {
      id: 4,
      text: 'Who discovered America in 1492?',
      options: ['Ferdinand Magellan', 'Vasco da Gama', 'Christopher Columbus', 'Marco Polo'],
      correctAnswer: 2,
    },
    {
      id: 5,
      text: 'What ancient wonder was located in Alexandria?',
      options: [
        'Hanging Gardens',
        'Colossus of Rhodes',
        'Lighthouse of Alexandria',
        'Temple of Artemis',
      ],
      correctAnswer: 2,
    },
  ],
};
