import { User } from '../App';
import { Sparkles, Truck, Shield, Palette } from 'lucide-react';

type HomeProps = {
  onNavigate: (page: string) => void;
  user: User | null;
};

export function Home({ onNavigate, user }: HomeProps) {
  const features = [
    {
      icon: Palette,
      title: 'Professional Templates',
      description: 'Choose from hundreds of professionally designed templates',
    },
    {
      icon: Sparkles,
      title: 'Easy Customization',
      description: 'Customize colors, fonts, and layouts with our intuitive editor',
    },
    {
      icon: Truck,
      title: 'Fast Delivery',
      description: 'Get your cards printed and delivered within 3-5 business days',
    },
    {
      icon: Shield,
      title: 'Premium Quality',
      description: 'Printed on high-quality cardstock with various finish options',
    },
  ];

  const steps = [
    {
      number: '1',
      title: 'Choose a Template',
      description: 'Browse our collection and select a design that fits your style',
    },
    {
      number: '2',
      title: 'Customize Your Card',
      description: 'Add your information and personalize colors, fonts, and layout',
    },
    {
      number: '3',
      title: 'Review & Order',
      description: 'Preview your design and place your order',
    },
    {
      number: '4',
      title: 'Receive Your Cards',
      description: 'Get professional business cards delivered to your door',
    },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="mb-6 text-white">
              Create Stunning Business Cards in Minutes
            </h1>
            <p className="text-indigo-100 max-w-2xl mx-auto mb-8">
              Design professional business cards that make a lasting impression. 
              Easy to create, beautiful to share, and delivered fast.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('templates')}
                className="px-8 py-3 bg-white text-indigo-600 rounded-lg hover:bg-indigo-50 transition-colors"
              >
                Start Designing
              </button>
              <button
                onClick={() => onNavigate('pricing')}
                className="px-8 py-3 bg-indigo-500 text-white rounded-lg hover:bg-indigo-400 transition-colors"
              >
                View Pricing
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">Why Choose CardCraft?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Everything you need to create and order professional business cards
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-6 rounded-xl border border-gray-200 hover:shadow-lg transition-shadow"
              >
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="size-6 text-indigo-600" />
                </div>
                <h3 className="mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">How It Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Create your perfect business card in four simple steps
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white rounded-xl p-6 h-full">
                  <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-full flex items-center justify-center mb-4">
                    <span className="text-xl">{step.number}</span>
                  </div>
                  <h3 className="mb-2">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2">
                    <div className="w-8 h-0.5 bg-indigo-200"></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sample Cards Preview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">Popular Designs</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Get inspired by our most popular business card templates
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="aspect-[1.75/1] bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg shadow-lg hover:shadow-xl transition-shadow cursor-pointer"
                onClick={() => onNavigate('templates')}
              >
                <div className="p-6 h-full flex flex-col justify-between">
                  <div>
                    <div className="w-8 h-8 bg-indigo-600 rounded mb-3"></div>
                    <h3>Professional {i === 1 ? 'Classic' : i === 2 ? 'Modern' : 'Elegant'}</h3>
                  </div>
                  <div className="text-gray-700">
                    <p>John Doe</p>
                    <p>CEO & Founder</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <button
              onClick={() => onNavigate('templates')}
              className="px-8 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Browse All Templates
            </button>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">What Our Customers Say</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: 'Sarah Johnson',
                role: 'Marketing Director',
                text: 'The quality exceeded my expectations! The design process was so easy and the cards arrived quickly.',
              },
              {
                name: 'Michael Chen',
                role: 'Freelance Designer',
                text: 'I\'ve ordered business cards from many places, but CardCraft offers the best combination of quality and price.',
              },
              {
                name: 'Emily Rodriguez',
                role: 'Startup Founder',
                text: 'Perfect for our growing team. The customization options allowed us to match our brand perfectly.',
              },
            ].map((testimonial, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-sm">
                <div className="text-yellow-400 mb-3">★★★★★</div>
                <p className="text-gray-700 mb-4">"{testimonial.text}"</p>
                <div>
                  <p className="text-gray-900">{testimonial.name}</p>
                  <p className="text-gray-600">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-indigo-600 to-purple-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="mb-4 text-white">Ready to Create Your Business Card?</h2>
          <p className="text-indigo-100 mb-8 max-w-2xl mx-auto">
            Join thousands of professionals who trust CardCraft for their business cards
          </p>
          <button
            onClick={() => onNavigate('templates')}
            className="px-8 py-3 bg-white text-indigo-600 rounded-lg hover:bg-indigo-50 transition-colors"
          >
            Get Started Now
          </button>
        </div>
      </section>
    </div>
  );
}
