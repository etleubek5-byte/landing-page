import { Check } from 'lucide-react';

type PricingProps = {
  onNavigate: (page: string) => void;
};

export function Pricing({ onNavigate }: PricingProps) {
  const plans = [
    {
      name: 'Starter',
      price: 29,
      quantity: '50 cards',
      features: [
        '50 premium business cards',
        'Standard cardstock (14pt)',
        'Matte or glossy finish',
        'Free design templates',
        'Standard shipping',
        'Digital proof',
      ],
      popular: false,
    },
    {
      name: 'Professional',
      price: 49,
      quantity: '100 cards',
      features: [
        '100 premium business cards',
        'Premium cardstock (16pt)',
        'Matte, glossy, or soft-touch finish',
        'All design templates',
        'Free standard shipping',
        'Digital proof',
        'Priority support',
      ],
      popular: true,
    },
    {
      name: 'Business',
      price: 89,
      quantity: '250 cards',
      features: [
        '250 premium business cards',
        'Ultra-premium cardstock (18pt)',
        'All finish options including spot UV',
        'Unlimited design revisions',
        'Free express shipping',
        'Physical proof option',
        'Dedicated account manager',
        'Rush printing available',
      ],
      popular: false,
    },
  ];

  const addOns = [
    {
      name: 'Rounded Corners',
      price: 10,
      description: 'Add elegant rounded corners to your cards',
    },
    {
      name: 'Spot UV Coating',
      price: 25,
      description: 'Highlight specific areas with glossy UV coating',
    },
    {
      name: 'Foil Stamping',
      price: 40,
      description: 'Metallic gold or silver foil accents',
    },
    {
      name: 'Express Production',
      price: 30,
      description: '1-2 day production (before shipping)',
    },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="mb-6 text-white">Simple, Transparent Pricing</h1>
          <p className="text-indigo-100 max-w-2xl mx-auto">
            Choose the perfect package for your needs. All plans include professional printing
            and free design tools.
          </p>
        </div>
      </section>

      {/* Pricing Plans */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <div
                key={index}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden ${
                  plan.popular ? 'ring-2 ring-indigo-600' : ''
                }`}
              >
                {plan.popular && (
                  <div className="bg-indigo-600 text-white text-center py-2">
                    Most Popular
                  </div>
                )}
                <div className="p-8">
                  <h3 className="mb-2">{plan.name}</h3>
                  <div className="mb-6">
                    <span className="text-indigo-600">
                      ${plan.price}
                    </span>
                    <span className="text-gray-600"> / {plan.quantity}</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start gap-3">
                        <Check className="size-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={() => onNavigate('templates')}
                    className={`w-full py-3 rounded-lg transition-colors ${
                      plan.popular
                        ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    }`}
                  >
                    Get Started
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Add-Ons */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">Premium Add-Ons</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Enhance your business cards with these premium options
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {addOns.map((addOn, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-lg p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-baseline gap-2 mb-3">
                  <span className="text-indigo-600">+${addOn.price}</span>
                </div>
                <h3 className="mb-2">{addOn.name}</h3>
                <p className="text-gray-600">{addOn.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">Compare Features</h2>
          </div>

          <div className="bg-white rounded-lg shadow-sm overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left text-gray-900">Feature</th>
                  <th className="px-6 py-4 text-center text-gray-900">Starter</th>
                  <th className="px-6 py-4 text-center text-gray-900">Professional</th>
                  <th className="px-6 py-4 text-center text-gray-900">Business</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 text-gray-700">Number of Cards</td>
                  <td className="px-6 py-4 text-center">50</td>
                  <td className="px-6 py-4 text-center">100</td>
                  <td className="px-6 py-4 text-center">250</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 text-gray-700">Cardstock Thickness</td>
                  <td className="px-6 py-4 text-center">14pt</td>
                  <td className="px-6 py-4 text-center">16pt</td>
                  <td className="px-6 py-4 text-center">18pt</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 text-gray-700">Finish Options</td>
                  <td className="px-6 py-4 text-center">2</td>
                  <td className="px-6 py-4 text-center">3</td>
                  <td className="px-6 py-4 text-center">All</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 text-gray-700">Design Revisions</td>
                  <td className="px-6 py-4 text-center">2</td>
                  <td className="px-6 py-4 text-center">5</td>
                  <td className="px-6 py-4 text-center">Unlimited</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 text-gray-700">Production Time</td>
                  <td className="px-6 py-4 text-center">5-7 days</td>
                  <td className="px-6 py-4 text-center">3-5 days</td>
                  <td className="px-6 py-4 text-center">1-3 days</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">Pricing FAQs</h2>
          </div>

          <div className="space-y-6">
            {[
              {
                question: 'What payment methods do you accept?',
                answer: 'We accept all major credit cards (Visa, Mastercard, American Express), PayPal, and bank transfers for larger orders.',
              },
              {
                question: 'Are there any hidden fees?',
                answer: 'No hidden fees! The price you see includes design tools, printing, and standard shipping. Add-ons and express shipping are optional extras.',
              },
              {
                question: 'Can I order more cards later with the same design?',
                answer: 'Yes! Save your design and reorder anytime. Repeat orders often qualify for discounts.',
              },
              {
                question: 'What if I\'m not satisfied with the quality?',
                answer: 'We offer a 100% satisfaction guarantee. If you\'re not happy with your cards, we\'ll reprint them or provide a full refund.',
              },
            ].map((faq, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-6">
                <h3 className="mb-3">{faq.question}</h3>
                <p className="text-gray-700">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-br from-indigo-600 to-purple-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="mb-4 text-white">Ready to Create Your Business Cards?</h2>
          <p className="text-indigo-100 mb-8 max-w-2xl mx-auto">
            Start designing now and see your vision come to life
          </p>
          <button
            onClick={() => onNavigate('templates')}
            className="px-8 py-3 bg-white text-indigo-600 rounded-lg hover:bg-indigo-50 transition-colors"
          >
            Start Designing
          </button>
        </div>
      </section>
    </div>
  );
}
