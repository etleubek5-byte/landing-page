import { useState, useEffect } from 'react';
import { FileText, Users, Send, CheckCircle } from 'lucide-react';

type Homework = {
  id: string;
  studentId: string;
  studentName: string;
  subject: string;
  title: string;
  description: string;
  dueDate: string;
  status: 'pending' | 'submitted' | 'graded';
  grade?: number;
  submittedDate?: string;
};

type AdminPanelProps = {
  onNavigate: (page: string) => void;
};

export function AdminPanel({ onNavigate }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'homework' | 'students'>('overview');
  const [homeworks, setHomeworks] = useState<Homework[]>([]);
  const [newHomework, setNewHomework] = useState({
    studentName: '',
    subject: '',
    title: '',
    description: '',
    dueDate: '',
  });

  useEffect(() => {
    // Load homework from localStorage
    const saved = localStorage.getItem('ent_bridge_homework');
    if (saved) {
      setHomeworks(JSON.parse(saved));
    } else {
      // Mock homework data
      const mockHomeworks: Homework[] = [
        {
          id: '1',
          studentId: 'student1',
          studentName: 'Assel Nurlan',
          subject: 'Mathematics',
          title: 'Algebra Practice Set 1',
          description: 'Complete exercises 1-20 from chapter 5',
          dueDate: '2025-12-10',
          status: 'submitted',
          submittedDate: '2025-12-08',
        },
        {
          id: '2',
          studentId: 'student2',
          studentName: 'Arman Bekov',
          subject: 'Physics',
          title: 'Newton\'s Laws Assignment',
          description: 'Solve problems related to force and motion',
          dueDate: '2025-12-12',
          status: 'pending',
        },
      ];
      setHomeworks(mockHomeworks);
      localStorage.setItem('ent_bridge_homework', JSON.stringify(mockHomeworks));
    }
  }, []);

  const handleCreateHomework = (e: React.FormEvent) => {
    e.preventDefault();
    
    const homework: Homework = {
      id: Math.random().toString(36).substr(2, 9),
      studentId: Math.random().toString(36).substr(2, 9),
      studentName: newHomework.studentName,
      subject: newHomework.subject,
      title: newHomework.title,
      description: newHomework.description,
      dueDate: newHomework.dueDate,
      status: 'pending',
    };

    const updated = [...homeworks, homework];
    setHomeworks(updated);
    localStorage.setItem('ent_bridge_homework', JSON.stringify(updated));

    // Reset form
    setNewHomework({
      studentName: '',
      subject: '',
      title: '',
      description: '',
      dueDate: '',
    });
  };

  const handleGrade = (homeworkId: string, grade: number) => {
    const updated = homeworks.map((hw) =>
      hw.id === homeworkId ? { ...hw, status: 'graded' as const, grade } : hw
    );
    setHomeworks(updated);
    localStorage.setItem('ent_bridge_homework', JSON.stringify(updated));
  };

  const pendingCount = homeworks.filter((hw) => hw.status === 'pending').length;
  const submittedCount = homeworks.filter((hw) => hw.status === 'submitted').length;
  const gradedCount = homeworks.filter((hw) => hw.status === 'graded').length;

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2">Admin Panel</h1>
          <p className="text-gray-600">Manage homework assignments and student progress</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <FileText className="size-6 text-yellow-600" />
              </div>
              <div>
                <div className="text-gray-600 mb-1">Pending</div>
                <div className="text-yellow-600">{pendingCount}</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Send className="size-6 text-blue-600" />
              </div>
              <div>
                <div className="text-gray-600 mb-1">Submitted</div>
                <div className="text-blue-600">{submittedCount}</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="size-6 text-green-600" />
              </div>
              <div>
                <div className="text-gray-600 mb-1">Graded</div>
                <div className="text-green-600">{gradedCount}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex gap-8 px-6">
              <button
                onClick={() => setActiveTab('overview')}
                className={`py-4 border-b-2 transition-colors ${
                  activeTab === 'overview'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-600 hover:text-gray-800'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab('homework')}
                className={`py-4 border-b-2 transition-colors ${
                  activeTab === 'homework'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-600 hover:text-gray-800'
                }`}
              >
                Homework Management
              </button>
              <button
                onClick={() => setActiveTab('students')}
                className={`py-4 border-b-2 transition-colors ${
                  activeTab === 'students'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-600 hover:text-gray-800'
                }`}
              >
                Students
              </button>
            </nav>
          </div>

          <div className="p-6">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div>
                <h2 className="mb-6">Recent Activity</h2>
                <div className="space-y-4">
                  {homeworks.slice(0, 5).map((hw) => (
                    <div
                      key={hw.id}
                      className="p-4 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h3>{hw.title}</h3>
                          <p className="text-gray-600">
                            {hw.studentName} - {hw.subject}
                          </p>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full ${
                            hw.status === 'graded'
                              ? 'bg-green-100 text-green-700'
                              : hw.status === 'submitted'
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-yellow-100 text-yellow-700'
                          }`}
                        >
                          {hw.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Homework Tab */}
            {activeTab === 'homework' && (
              <div>
                <h2 className="mb-6">Create New Homework</h2>
                <form onSubmit={handleCreateHomework} className="bg-gray-50 rounded-lg p-6 mb-8">
                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="studentName" className="block mb-2 text-gray-700">
                        Student Name
                      </label>
                      <input
                        id="studentName"
                        type="text"
                        required
                        value={newHomework.studentName}
                        onChange={(e) =>
                          setNewHomework({ ...newHomework, studentName: e.target.value })
                        }
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                        placeholder="Enter student name"
                      />
                    </div>
                    <div>
                      <label htmlFor="subject" className="block mb-2 text-gray-700">
                        Subject
                      </label>
                      <input
                        id="subject"
                        type="text"
                        required
                        value={newHomework.subject}
                        onChange={(e) =>
                          setNewHomework({ ...newHomework, subject: e.target.value })
                        }
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                        placeholder="e.g., Mathematics"
                      />
                    </div>
                  </div>
                  <div className="mb-4">
                    <label htmlFor="title" className="block mb-2 text-gray-700">
                      Assignment Title
                    </label>
                    <input
                      id="title"
                      type="text"
                      required
                      value={newHomework.title}
                      onChange={(e) =>
                        setNewHomework({ ...newHomework, title: e.target.value })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                      placeholder="Enter assignment title"
                    />
                  </div>
                  <div className="mb-4">
                    <label htmlFor="description" className="block mb-2 text-gray-700">
                      Description
                    </label>
                    <textarea
                      id="description"
                      required
                      value={newHomework.description}
                      onChange={(e) =>
                        setNewHomework({ ...newHomework, description: e.target.value })
                      }
                      rows={3}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                      placeholder="Enter assignment description"
                    />
                  </div>
                  <div className="mb-4">
                    <label htmlFor="dueDate" className="block mb-2 text-gray-700">
                      Due Date
                    </label>
                    <input
                      id="dueDate"
                      type="date"
                      required
                      value={newHomework.dueDate}
                      onChange={(e) =>
                        setNewHomework({ ...newHomework, dueDate: e.target.value })
                      }
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Create Assignment
                  </button>
                </form>

                <h2 className="mb-6">All Homework Assignments</h2>
                <div className="space-y-4">
                  {homeworks.map((hw) => (
                    <div
                      key={hw.id}
                      className="p-6 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3>{hw.title}</h3>
                          <p className="text-gray-600">
                            {hw.studentName} - {hw.subject}
                          </p>
                          <p className="text-gray-600 mt-2">{hw.description}</p>
                          <p className="text-gray-600 mt-2">
                            Due: {new Date(hw.dueDate).toLocaleDateString()}
                          </p>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full ${
                            hw.status === 'graded'
                              ? 'bg-green-100 text-green-700'
                              : hw.status === 'submitted'
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-yellow-100 text-yellow-700'
                          }`}
                        >
                          {hw.status}
                        </span>
                      </div>
                      {hw.status === 'submitted' && (
                        <div className="flex items-center gap-4">
                          <label htmlFor={`grade-${hw.id}`} className="text-gray-700">
                            Grade:
                          </label>
                          <input
                            id={`grade-${hw.id}`}
                            type="number"
                            min="0"
                            max="100"
                            className="px-3 py-2 border border-gray-300 rounded-lg w-24"
                            placeholder="0-100"
                            onBlur={(e) => {
                              const grade = parseInt(e.target.value);
                              if (grade >= 0 && grade <= 100) {
                                handleGrade(hw.id, grade);
                              }
                            }}
                          />
                        </div>
                      )}
                      {hw.status === 'graded' && (
                        <div className="text-green-600">
                          Grade: {hw.grade}/100
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Students Tab */}
            {activeTab === 'students' && (
              <div>
                <h2 className="mb-6">Student Overview</h2>
                <div className="space-y-4">
                  {Array.from(new Set(homeworks.map((hw) => hw.studentName))).map(
                    (studentName) => {
                      const studentHomeworks = homeworks.filter(
                        (hw) => hw.studentName === studentName
                      );
                      const completed = studentHomeworks.filter(
                        (hw) => hw.status === 'graded'
                      ).length;

                      return (
                        <div
                          key={studentName}
                          className="p-6 bg-gray-50 rounded-lg"
                        >
                          <div className="flex items-center gap-4 mb-4">
                            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                              <Users className="size-6 text-blue-600" />
                            </div>
                            <div>
                              <h3>{studentName}</h3>
                              <p className="text-gray-600">
                                {completed} / {studentHomeworks.length} assignments completed
                              </p>
                            </div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full"
                              style={{
                                width: `${
                                  (completed / studentHomeworks.length) * 100
                                }%`,
                              }}
                            />
                          </div>
                        </div>
                      );
                    }
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
