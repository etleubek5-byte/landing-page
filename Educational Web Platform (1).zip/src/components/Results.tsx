import { TestResult } from '../App';
import { SUBJECTS } from '../data/subjects';
import { Trophy, TrendingUp, RotateCcw, Home } from 'lucide-react';

type ResultsProps = {
  result: TestResult;
  onNavigate: (page: string) => void;
};

export function Results({ result, onNavigate }: ResultsProps) {
  const subject = SUBJECTS.find((s) => s.id === result.subjectId);
  const percentage = Math.round((result.score / result.maxScore) * 100);

  const getGrade = (percent: number) => {
    if (percent >= 90) return { grade: 'A', color: 'text-green-600', bg: 'bg-green-50' };
    if (percent >= 80) return { grade: 'B', color: 'text-blue-600', bg: 'bg-blue-50' };
    if (percent >= 70) return { grade: 'C', color: 'text-yellow-600', bg: 'bg-yellow-50' };
    if (percent >= 60) return { grade: 'D', color: 'text-orange-600', bg: 'bg-orange-50' };
    return { grade: 'F', color: 'text-red-600', bg: 'bg-red-50' };
  };

  const gradeInfo = getGrade(percentage);

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-100 rounded-full mb-4">
            <Trophy className="size-10 text-blue-600" />
          </div>
          <h1 className="mb-2">Test Complete!</h1>
          <p className="text-gray-600">
            Here are your results for {subject?.name}
          </p>
        </div>

        {/* Score Card */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
          <div className="text-center mb-8">
            <div className="inline-flex items-baseline gap-2 mb-2">
              <span className="text-blue-600">
                {result.score}
              </span>
              <span className="text-gray-500">
                / {result.maxScore}
              </span>
            </div>
            <p className="text-gray-600">Total Score</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className={`p-6 rounded-lg ${gradeInfo.bg}`}>
              <div className="text-center">
                <div className={`text-6xl mb-2 ${gradeInfo.color}`}>
                  {gradeInfo.grade}
                </div>
                <p className="text-gray-600">Grade</p>
              </div>
            </div>

            <div className="p-6 rounded-lg bg-blue-50">
              <div className="text-center">
                <div className="text-blue-600 mb-2">
                  {percentage}%
                </div>
                <p className="text-gray-600">Accuracy</p>
              </div>
            </div>
          </div>

          {/* Performance Bar */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600">Performance</span>
              <span className={gradeInfo.color}>
                {percentage >= 70 ? 'Good Job!' : 'Keep Practicing!'}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className={`h-3 rounded-full transition-all ${
                  percentage >= 70 ? 'bg-green-500' : 'bg-yellow-500'
                }`}
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        </div>

        {/* Feedback */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-start gap-4">
            <TrendingUp className="size-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="mb-2">Performance Feedback</h3>
              {percentage >= 90 && (
                <p className="text-gray-700">
                  Excellent work! You have a strong understanding of {subject?.name}. 
                  Keep up this level of performance!
                </p>
              )}
              {percentage >= 70 && percentage < 90 && (
                <p className="text-gray-700">
                  Good job! You're on the right track with {subject?.name}. 
                  Review the topics where you made mistakes to improve further.
                </p>
              )}
              {percentage >= 50 && percentage < 70 && (
                <p className="text-gray-700">
                  You're making progress with {subject?.name}. 
                  Focus on reviewing the material and practice more questions.
                </p>
              )}
              {percentage < 50 && (
                <p className="text-gray-700">
                  You need more practice with {subject?.name}. 
                  Consider watching video lessons and reviewing the material before retaking the test.
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="grid md:grid-cols-3 gap-4">
          <button
            onClick={() => onNavigate('subjects')}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <RotateCcw className="size-5" />
            Try Another Test
          </button>
          
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-white border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <TrendingUp className="size-5" />
            View Progress
          </button>
          
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-white border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Home className="size-5" />
            Home
          </button>
        </div>

        {/* Study Resources */}
        <div className="mt-6 p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl">
          <h3 className="mb-3">Want to improve your score?</h3>
          <p className="text-gray-700 mb-4">
            Check out our video lessons for {subject?.name} to strengthen your understanding.
          </p>
          <button
            onClick={() => onNavigate('videos')}
            className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            Watch Video Lessons
          </button>
        </div>
      </div>
    </div>
  );
}
