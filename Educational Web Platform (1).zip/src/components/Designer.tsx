import { useState, useEffect } from 'react';
import { BusinessCard, User } from '../App';
import { TEMPLATES } from '../data/templates';
import { Save, RotateCcw, Eye, ShoppingCart } from 'lucide-react';

type DesignerProps = {
  templateId: string | null;
  editingCard: BusinessCard | null;
  user: User | null;
  onNavigate: (page: string) => void;
  onSave: () => void;
};

export function Designer({ templateId, editingCard, user, onNavigate, onSave }: DesignerProps) {
  const template = templateId ? TEMPLATES.find((t) => t.id === templateId) : null;
  const initialTemplate = editingCard 
    ? TEMPLATES.find((t) => t.id === editingCard.templateId) 
    : template;

  const [cardData, setCardData] = useState({
    name: editingCard?.name || user?.name || '',
    title: editingCard?.title || '',
    company: editingCard?.company || user?.company || '',
    email: editingCard?.email || user?.email || '',
    phone: editingCard?.phone || '',
    website: editingCard?.website || '',
    address: editingCard?.address || '',
  });

  const [customizations, setCustomizations] = useState({
    primaryColor: editingCard?.customizations.primaryColor || initialTemplate?.primaryColor || '#3B82F6',
    secondaryColor: editingCard?.customizations.secondaryColor || initialTemplate?.secondaryColor || '#1E40AF',
    fontStyle: editingCard?.customizations.fontStyle || 'modern',
    layout: editingCard?.customizations.layout || initialTemplate?.layout || 'standard',
  });

  const [showPreview, setShowPreview] = useState(false);

  if (!user) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="text-center">
          <h2 className="mb-4">Please log in to design your card</h2>
          <button
            onClick={() => onNavigate('auth')}
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            Login
          </button>
        </div>
      </div>
    );
  }

  const handleSave = () => {
    const card: BusinessCard = {
      id: editingCard?.id || Math.random().toString(36).substr(2, 9),
      userId: user.id,
      templateId: templateId || editingCard?.templateId || 'modern-blue',
      ...cardData,
      customizations,
      createdAt: editingCard?.createdAt || new Date().toISOString(),
      status: editingCard?.status || 'draft',
    };

    // Save to localStorage
    const savedCards = localStorage.getItem('business_cards');
    const cards: BusinessCard[] = savedCards ? JSON.parse(savedCards) : [];
    
    if (editingCard) {
      // Update existing card
      const index = cards.findIndex((c) => c.id === editingCard.id);
      if (index !== -1) {
        cards[index] = card;
      }
    } else {
      // Add new card
      cards.push(card);
    }
    
    localStorage.setItem('business_cards', JSON.stringify(cards));
    onSave();
  };

  const handleReset = () => {
    if (confirm('Are you sure you want to reset all changes?')) {
      setCardData({
        name: user?.name || '',
        title: '',
        company: user?.company || '',
        email: user?.email || '',
        phone: '',
        website: '',
        address: '',
      });
      setCustomizations({
        primaryColor: initialTemplate?.primaryColor || '#3B82F6',
        secondaryColor: initialTemplate?.secondaryColor || '#1E40AF',
        fontStyle: 'modern',
        layout: initialTemplate?.layout || 'standard',
      });
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2">Design Your Business Card</h1>
          <p className="text-gray-600">
            Customize your card with your information and style preferences
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Editor Panel */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="mb-6">Card Information</h2>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="name" className="block mb-2 text-gray-700">
                  Full Name *
                </label>
                <input
                  id="name"
                  type="text"
                  required
                  value={cardData.name}
                  onChange={(e) => setCardData({ ...cardData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                  placeholder="John Doe"
                />
              </div>

              <div>
                <label htmlFor="title" className="block mb-2 text-gray-700">
                  Job Title *
                </label>
                <input
                  id="title"
                  type="text"
                  required
                  value={cardData.title}
                  onChange={(e) => setCardData({ ...cardData, title: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                  placeholder="CEO & Founder"
                />
              </div>

              <div>
                <label htmlFor="company" className="block mb-2 text-gray-700">
                  Company Name *
                </label>
                <input
                  id="company"
                  type="text"
                  required
                  value={cardData.company}
                  onChange={(e) => setCardData({ ...cardData, company: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                  placeholder="Your Company"
                />
              </div>

              <div>
                <label htmlFor="email" className="block mb-2 text-gray-700">
                  Email *
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  value={cardData.email}
                  onChange={(e) => setCardData({ ...cardData, email: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                  placeholder="john@example.com"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block mb-2 text-gray-700">
                  Phone *
                </label>
                <input
                  id="phone"
                  type="tel"
                  required
                  value={cardData.phone}
                  onChange={(e) => setCardData({ ...cardData, phone: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                  placeholder="+1 (555) 123-4567"
                />
              </div>

              <div>
                <label htmlFor="website" className="block mb-2 text-gray-700">
                  Website
                </label>
                <input
                  id="website"
                  type="url"
                  value={cardData.website}
                  onChange={(e) => setCardData({ ...cardData, website: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                  placeholder="www.example.com"
                />
              </div>

              <div>
                <label htmlFor="address" className="block mb-2 text-gray-700">
                  Address
                </label>
                <input
                  id="address"
                  type="text"
                  value={cardData.address}
                  onChange={(e) => setCardData({ ...cardData, address: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                  placeholder="123 Main St, City, State"
                />
              </div>
            </div>

            <h2 className="mt-8 mb-6">Customization</h2>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="primaryColor" className="block mb-2 text-gray-700">
                  Primary Color
                </label>
                <div className="flex gap-3">
                  <input
                    id="primaryColor"
                    type="color"
                    value={customizations.primaryColor}
                    onChange={(e) => setCustomizations({ ...customizations, primaryColor: e.target.value })}
                    className="w-16 h-10 rounded border border-gray-300 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={customizations.primaryColor}
                    onChange={(e) => setCustomizations({ ...customizations, primaryColor: e.target.value })}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="secondaryColor" className="block mb-2 text-gray-700">
                  Secondary Color
                </label>
                <div className="flex gap-3">
                  <input
                    id="secondaryColor"
                    type="color"
                    value={customizations.secondaryColor}
                    onChange={(e) => setCustomizations({ ...customizations, secondaryColor: e.target.value })}
                    className="w-16 h-10 rounded border border-gray-300 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={customizations.secondaryColor}
                    onChange={(e) => setCustomizations({ ...customizations, secondaryColor: e.target.value })}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="fontStyle" className="block mb-2 text-gray-700">
                  Font Style
                </label>
                <select
                  id="fontStyle"
                  value={customizations.fontStyle}
                  onChange={(e) => setCustomizations({ ...customizations, fontStyle: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                >
                  <option value="modern">Modern</option>
                  <option value="classic">Classic</option>
                  <option value="elegant">Elegant</option>
                </select>
              </div>
            </div>
          </div>

          {/* Preview Panel */}
          <div className="lg:sticky lg:top-24 h-fit">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-6">
                <h2>Preview</h2>
                <button
                  onClick={() => setShowPreview(!showPreview)}
                  className="flex items-center gap-2 px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                >
                  <Eye className="size-5" />
                  {showPreview ? 'Edit Mode' : 'Preview Mode'}
                </button>
              </div>

              {/* Front of Card */}
              <div className="mb-4">
                <p className="text-gray-600 mb-2">Front</p>
                <div 
                  className="aspect-[1.75/1] rounded-lg shadow-xl"
                  style={{
                    background: `linear-gradient(135deg, ${customizations.primaryColor} 0%, ${customizations.secondaryColor} 100%)`
                  }}
                >
                  <div className="p-8 h-full flex flex-col justify-between text-white">
                    <div>
                      <div className="w-12 h-12 bg-white/20 rounded mb-4"></div>
                      <h3 className="text-white mb-1">{cardData.name || 'Your Name'}</h3>
                      <p className="text-white/90">{cardData.title || 'Your Title'}</p>
                    </div>
                    <div>
                      <p className="text-white/90">{cardData.company || 'Your Company'}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Back of Card */}
              <div>
                <p className="text-gray-600 mb-2">Back</p>
                <div className="aspect-[1.75/1] rounded-lg shadow-xl bg-white border border-gray-200">
                  <div className="p-8 h-full flex flex-col justify-center">
                    <div className="space-y-2 text-gray-700">
                      {cardData.email && <p>📧 {cardData.email}</p>}
                      {cardData.phone && <p>📱 {cardData.phone}</p>}
                      {cardData.website && <p>🌐 {cardData.website}</p>}
                      {cardData.address && <p>📍 {cardData.address}</p>}
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex gap-3">
                <button
                  onClick={handleReset}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <RotateCcw className="size-5" />
                  Reset
                </button>
                <button
                  onClick={handleSave}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  <Save className="size-5" />
                  Save Design
                </button>
              </div>

              <button
                onClick={() => {
                  handleSave();
                  onNavigate('pricing');
                }}
                className="w-full mt-3 flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <ShoppingCart className="size-5" />
                Save & Order
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
