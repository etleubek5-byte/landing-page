import { useState } from 'react';
import { SUBJECTS } from '../data/subjects';
import { Play, Filter } from 'lucide-react';

type VideoLessonsProps = {
  onNavigate: (page: string) => void;
};

type VideoLesson = {
  id: string;
  subjectId: string;
  title: string;
  description: string;
  videoId: string;
  duration: string;
  level: 'beginner' | 'intermediate' | 'advanced';
};

const MOCK_VIDEOS: VideoLesson[] = [
  {
    id: '1',
    subjectId: 'history-kz',
    title: 'Introduction to Kazakhstan History',
    description: 'Overview of Kazakhstan\'s historical timeline and key events',
    videoId: 'dQw4w9WgXcQ',
    duration: '15:30',
    level: 'beginner',
  },
  {
    id: '2',
    subjectId: 'history-kz',
    title: 'Kazakhstan Independence Era',
    description: 'Detailed look at Kazakhstan\'s path to independence',
    videoId: 'dQw4w9WgXcQ',
    duration: '22:45',
    level: 'intermediate',
  },
  {
    id: '3',
    subjectId: 'math-literacy',
    title: 'Mathematical Problem Solving',
    description: 'Strategies for solving mathematical literacy questions',
    videoId: 'dQw4w9WgXcQ',
    duration: '18:20',
    level: 'beginner',
  },
  {
    id: '4',
    subjectId: 'math-literacy',
    title: 'Percentages and Ratios',
    description: 'Master percentage calculations and ratio problems',
    videoId: 'dQw4w9WgXcQ',
    duration: '25:15',
    level: 'intermediate',
  },
  {
    id: '5',
    subjectId: 'reading-literacy',
    title: 'Reading Comprehension Strategies',
    description: 'Techniques for improving reading comprehension skills',
    videoId: 'dQw4w9WgXcQ',
    duration: '20:00',
    level: 'beginner',
  },
  {
    id: '6',
    subjectId: 'mathematics',
    title: 'Algebra Fundamentals',
    description: 'Core algebraic concepts and equation solving',
    videoId: 'dQw4w9WgXcQ',
    duration: '30:45',
    level: 'intermediate',
  },
  {
    id: '7',
    subjectId: 'physics',
    title: 'Newton\'s Laws of Motion',
    description: 'Understanding the fundamental laws of physics',
    videoId: 'dQw4w9WgXcQ',
    duration: '28:30',
    level: 'intermediate',
  },
  {
    id: '8',
    subjectId: 'chemistry',
    title: 'Chemical Bonds and Reactions',
    description: 'Learn about different types of chemical bonds',
    videoId: 'dQw4w9WgXcQ',
    duration: '26:15',
    level: 'beginner',
  },
];

export function VideoLessons({ onNavigate }: VideoLessonsProps) {
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [selectedVideo, setSelectedVideo] = useState<VideoLesson | null>(null);

  const filteredVideos = MOCK_VIDEOS.filter((video) => {
    if (selectedSubject !== 'all' && video.subjectId !== selectedSubject) {
      return false;
    }
    if (selectedLevel !== 'all' && video.level !== selectedLevel) {
      return false;
    }
    return true;
  });

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'beginner':
        return 'bg-green-100 text-green-700';
      case 'intermediate':
        return 'bg-yellow-100 text-yellow-700';
      case 'advanced':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2">Video Lessons</h1>
          <p className="text-gray-600">
            Learn from expert teachers and prepare for your UNT exam
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="size-5 text-gray-600" />
            <h3>Filter Lessons</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="subject" className="block mb-2 text-gray-700">
                Subject
              </label>
              <select
                id="subject"
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              >
                <option value="all">All Subjects</option>
                {SUBJECTS.map((subject) => (
                  <option key={subject.id} value={subject.id}>
                    {subject.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="level" className="block mb-2 text-gray-700">
                Level
              </label>
              <select
                id="level"
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              >
                <option value="all">All Levels</option>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </div>
          </div>
        </div>

        {/* Video Player (if selected) */}
        {selectedVideo && (
          <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
            <div className="aspect-video bg-gray-900 rounded-lg mb-4 flex items-center justify-center">
              <div className="text-white text-center">
                <Play className="size-16 mx-auto mb-4 opacity-50" />
                <p className="text-gray-400">
                  Video player would display here
                </p>
                <p className="text-gray-500 mt-2">
                  YouTube ID: {selectedVideo.videoId}
                </p>
              </div>
            </div>
            <div className="flex items-start justify-between">
              <div>
                <h2 className="mb-2">{selectedVideo.title}</h2>
                <p className="text-gray-600 mb-4">{selectedVideo.description}</p>
                <div className="flex items-center gap-4">
                  <span
                    className={`px-3 py-1 rounded-full ${getLevelColor(
                      selectedVideo.level
                    )}`}
                  >
                    {selectedVideo.level}
                  </span>
                  <span className="text-gray-600">{selectedVideo.duration}</span>
                </div>
              </div>
              <button
                onClick={() => setSelectedVideo(null)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800"
              >
                Close
              </button>
            </div>
          </div>
        )}

        {/* Video Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => {
            const subject = SUBJECTS.find((s) => s.id === video.subjectId);

            return (
              <button
                key={video.id}
                onClick={() => setSelectedVideo(video)}
                className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-lg transition-shadow text-left"
              >
                <div className="aspect-video bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                  <Play className="size-12 text-blue-600" />
                </div>
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-blue-600">{subject?.name}</span>
                    <span
                      className={`px-2 py-0.5 rounded-full ${getLevelColor(
                        video.level
                      )}`}
                    >
                      {video.level}
                    </span>
                  </div>
                  <h3 className="mb-2">{video.title}</h3>
                  <p className="text-gray-600 mb-3 line-clamp-2">
                    {video.description}
                  </p>
                  <span className="text-gray-500">{video.duration}</span>
                </div>
              </button>
            );
          })}
        </div>

        {filteredVideos.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg">
            <p className="text-gray-600 mb-4">
              No videos found for the selected filters
            </p>
            <button
              onClick={() => {
                setSelectedSubject('all');
                setSelectedLevel('all');
              }}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
