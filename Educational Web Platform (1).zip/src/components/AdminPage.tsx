import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { mockHomework, subjects, mockUsers, mockTestResults } from '../data/mockData';
import { useAuth } from '../contexts/AuthContext';
import { FileText, Users, BarChart, Plus, Calendar, CheckCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export const AdminPage: React.FC = () => {
  const { user } = useAuth();
  const [isAddingHomework, setIsAddingHomework] = useState(false);
  const [newHomework, setNewHomework] = useState({
    title: '',
    description: '',
    subjectId: '',
    dueDate: '',
  });

  if (!user?.isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card>
          <CardContent className="pt-6">
            <p className="text-muted-foreground">
              У вас нет доступа к панели администратора
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleAddHomework = () => {
    if (!newHomework.title || !newHomework.description || !newHomework.subjectId || !newHomework.dueDate) {
      toast('Пожалуйста, заполните все поля');
      return;
    }

    toast('Домашнее задание успешно добавлено');
    setIsAddingHomework(false);
    setNewHomework({
      title: '',
      description: '',
      subjectId: '',
      dueDate: '',
    });
  };

  const totalStudents = mockUsers.filter(u => !u.isAdmin).length;
  const totalTests = mockTestResults.length;
  const totalHomework = mockHomework.length;

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="mb-8">
          <h1 className="mb-2">Панель администратора</h1>
          <p className="text-muted-foreground">
            Управление платформой, студентами и заданиями
          </p>
        </div>

        {/* Statistics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Users className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-muted-foreground">Студентов</p>
                  <div className="text-2xl">{totalStudents}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <BarChart className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-muted-foreground">Пройдено тестов</p>
                  <div className="text-2xl">{totalTests}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <FileText className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-muted-foreground">Заданий</p>
                  <div className="text-2xl">{totalHomework}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-muted-foreground">Активных предметов</p>
                  <div className="text-2xl">{subjects.length}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="homework" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="homework">Домашние задания</TabsTrigger>
            <TabsTrigger value="students">Студенты</TabsTrigger>
            <TabsTrigger value="results">Результаты тестов</TabsTrigger>
          </TabsList>

          <TabsContent value="homework" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Управление домашними заданиями</CardTitle>
                    <CardDescription>
                      Создавайте и управляйте домашними заданиями для студентов
                    </CardDescription>
                  </div>
                  <Dialog open={isAddingHomework} onOpenChange={setIsAddingHomework}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Добавить задание
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Новое домашнее задание</DialogTitle>
                        <DialogDescription>
                          Заполните форму для создания нового задания
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="title">Название</Label>
                          <Input
                            id="title"
                            value={newHomework.title}
                            onChange={(e) => setNewHomework({ ...newHomework, title: e.target.value })}
                            placeholder="Например: Решение уравнений"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="description">Описание</Label>
                          <Textarea
                            id="description"
                            value={newHomework.description}
                            onChange={(e) => setNewHomework({ ...newHomework, description: e.target.value })}
                            placeholder="Подробное описание задания..."
                            rows={4}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="subject">Предмет</Label>
                          <Select value={newHomework.subjectId} onValueChange={(value) => setNewHomework({ ...newHomework, subjectId: value })}>
                            <SelectTrigger>
                              <SelectValue placeholder="Выберите предмет" />
                            </SelectTrigger>
                            <SelectContent>
                              {subjects.map(subject => (
                                <SelectItem key={subject.id} value={subject.id}>
                                  {subject.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="dueDate">Срок сдачи</Label>
                          <Input
                            id="dueDate"
                            type="date"
                            value={newHomework.dueDate}
                            onChange={(e) => setNewHomework({ ...newHomework, dueDate: e.target.value })}
                          />
                        </div>

                        <div className="flex gap-3">
                          <Button onClick={handleAddHomework}>
                            Создать задание
                          </Button>
                          <Button variant="outline" onClick={() => setIsAddingHomework(false)}>
                            Отмена
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockHomework.map(hw => {
                    const subject = subjects.find(s => s.id === hw.subjectId);
                    
                    return (
                      <Card key={hw.id}>
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <CardTitle>{hw.title}</CardTitle>
                              <CardDescription>{hw.description}</CardDescription>
                            </div>
                            <Badge>{subject?.name}</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4" />
                              <span>
                                Срок: {new Date(hw.dueDate).toLocaleDateString('ru-RU')}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4" />
                              <span>{hw.submissions.length} сдано</span>
                            </div>
                          </div>
                          <div className="mt-4">
                            <Button size="sm" variant="outline">
                              Просмотреть работы
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="students">
            <Card>
              <CardHeader>
                <CardTitle>Список студентов</CardTitle>
                <CardDescription>
                  Все зарегистрированные студенты на платформе
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Имя</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Имя пользователя</TableHead>
                      <TableHead>Дата регистрации</TableHead>
                      <TableHead>Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockUsers.filter(u => !u.isAdmin).map(student => (
                      <TableRow key={student.id}>
                        <TableCell>{student.name}</TableCell>
                        <TableCell>{student.email}</TableCell>
                        <TableCell>{student.username}</TableCell>
                        <TableCell>
                          {new Date(student.createdAt).toLocaleDateString('ru-RU')}
                        </TableCell>
                        <TableCell>
                          <Button size="sm" variant="outline">
                            Просмотр
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results">
            <Card>
              <CardHeader>
                <CardTitle>Результаты тестов</CardTitle>
                <CardDescription>
                  Результаты всех пройденных тестов
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Студент</TableHead>
                      <TableHead>Предмет</TableHead>
                      <TableHead>Балл</TableHead>
                      <TableHead>Правильных ответов</TableHead>
                      <TableHead>Дата</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockTestResults.map(result => {
                      const student = mockUsers.find(u => u.id === result.userId);
                      const percentage = Math.round((result.score / result.maxScore) * 100);
                      
                      return (
                        <TableRow key={result.id}>
                          <TableCell>{student?.name || 'Unknown'}</TableCell>
                          <TableCell>{result.subjectName}</TableCell>
                          <TableCell>
                            <Badge variant={percentage >= 75 ? 'default' : 'secondary'}>
                              {result.score} / {result.maxScore}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {result.correctAnswers} / {result.totalQuestions}
                          </TableCell>
                          <TableCell>
                            {new Date(result.date).toLocaleDateString('ru-RU')}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};
