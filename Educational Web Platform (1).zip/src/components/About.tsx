import { Award, Users, Sparkles, TrendingUp } from 'lucide-react';

type AboutProps = {
  onNavigate: (page: string) => void;
};

export function About({ onNavigate }: AboutProps) {
  const values = [
    {
      icon: Award,
      title: 'Premium Quality',
      description:
        'We use only the finest cardstock and printing techniques to ensure your business cards look professional and feel luxurious.',
    },
    {
      icon: Users,
      title: 'Customer First',
      description:
        'Your satisfaction is our priority. We offer unlimited revisions and a 100% satisfaction guarantee on all orders.',
    },
    {
      icon: Sparkles,
      title: 'Easy to Use',
      description:
        'Our intuitive design tools make it simple to create stunning business cards, even if you have no design experience.',
    },
    {
      icon: TrendingUp,
      title: 'Fast Turnaround',
      description:
        'Get your professionally printed business cards delivered quickly with our efficient production and shipping process.',
    },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="mb-6 text-white">About CardCraft</h1>
          <p className="text-indigo-100 max-w-3xl mx-auto">
            We're on a mission to make professional business cards accessible to everyone.
            From freelancers to Fortune 500 companies, we help you make a memorable first impression.
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  CardCraft was founded in 2020 with a simple idea: creating professional
                  business cards shouldn't be complicated or expensive.
                </p>
                <p>
                  We noticed that most business card services were either too expensive,
                  had limited design options, or required extensive design knowledge.
                  We set out to change that.
                </p>
                <p>
                  Today, we've helped over 50,000 professionals and businesses create
                  stunning business cards that make lasting impressions. Our combination
                  of easy-to-use design tools, premium quality printing, and affordable
                  pricing has made us a trusted partner for businesses worldwide.
                </p>
              </div>
            </div>
            <div className="bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl p-8">
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-indigo-600 text-white rounded-lg flex items-center justify-center">
                    <span className="text-2xl">50K+</span>
                  </div>
                  <div>
                    <h3>Happy Customers</h3>
                    <p className="text-gray-600">Worldwide</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-purple-600 text-white rounded-lg flex items-center justify-center">
                    <span className="text-2xl">1M+</span>
                  </div>
                  <div>
                    <h3>Cards Printed</h3>
                    <p className="text-gray-600">And counting</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-pink-600 text-white rounded-lg flex items-center justify-center">
                    <span className="text-2xl">4.9★</span>
                  </div>
                  <div>
                    <h3>Customer Rating</h3>
                    <p className="text-gray-600">Average review score</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">What We Stand For</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our core values guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="bg-white p-8 rounded-xl hover:shadow-lg transition-shadow"
              >
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <value.icon className="size-6 text-indigo-600" />
                </div>
                <h3 className="mb-3">{value.title}</h3>
                <p className="text-gray-700">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">Our Process</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              How we ensure quality at every step
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Design',
                description: 'Choose from hundreds of templates or create your own with our easy-to-use editor. Preview your design in real-time.',
              },
              {
                title: 'Print',
                description: 'We use state-of-the-art printing equipment and premium cardstock to ensure vibrant colors and crisp details.',
              },
              {
                title: 'Deliver',
                description: 'Your cards are carefully packaged and shipped directly to your door. Track your order every step of the way.',
              },
            ].map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">{index + 1}</span>
                </div>
                <h3 className="mb-3">{step.title}</h3>
                <p className="text-gray-700">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="mb-4">Meet Our Team</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              The people behind CardCraft
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { name: 'Sarah Johnson', role: 'CEO & Founder' },
              { name: 'Michael Chen', role: 'Head of Design' },
              { name: 'Emily Rodriguez', role: 'Production Manager' },
              { name: 'David Kim', role: 'Customer Success' },
            ].map((member, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 text-center hover:shadow-lg transition-shadow"
              >
                <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">{member.name.charAt(0)}</span>
                </div>
                <h3 className="mb-1">{member.name}</h3>
                <p className="text-indigo-600">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-indigo-600 to-purple-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="mb-6 text-white">Ready to Create Your Business Cards?</h2>
          <p className="text-indigo-100 mb-8 max-w-2xl mx-auto">
            Join thousands of professionals who trust CardCraft
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('templates')}
              className="px-8 py-3 bg-white text-indigo-600 rounded-lg hover:bg-indigo-50 transition-colors"
            >
              Start Designing
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="px-8 py-3 bg-indigo-500 text-white rounded-lg hover:bg-indigo-400 transition-colors"
            >
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
