import { useState, useEffect } from 'react';
import { BusinessCard, User } from '../App';
import { TEMPLATES } from '../data/templates';
import { Edit, Trash2, ShoppingCart, Eye, Download } from 'lucide-react';

type MyCardsProps = {
  user: User | null;
  onNavigate: (page: string) => void;
  onEditCard: (card: BusinessCard) => void;
};

export function MyCards({ user, onNavigate, onEditCard }: MyCardsProps) {
  const [cards, setCards] = useState<BusinessCard[]>([]);
  const [selectedCard, setSelectedCard] = useState<BusinessCard | null>(null);

  useEffect(() => {
    if (user) {
      const savedCards = localStorage.getItem('business_cards');
      if (savedCards) {
        const allCards: BusinessCard[] = JSON.parse(savedCards);
        const userCards = allCards.filter((c) => c.userId === user.id);
        setCards(userCards);
      }
    }
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="text-center">
          <h2 className="mb-4">Please log in to view your cards</h2>
          <button
            onClick={() => onNavigate('auth')}
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            Login
          </button>
        </div>
      </div>
    );
  }

  const handleDelete = (cardId: string) => {
    if (confirm('Are you sure you want to delete this card design?')) {
      const savedCards = localStorage.getItem('business_cards');
      if (savedCards) {
        const allCards: BusinessCard[] = JSON.parse(savedCards);
        const filtered = allCards.filter((c) => c.id !== cardId);
        localStorage.setItem('business_cards', JSON.stringify(filtered));
        setCards(cards.filter((c) => c.id !== cardId));
        if (selectedCard?.id === cardId) {
          setSelectedCard(null);
        }
      }
    }
  };

  const getStatusColor = (status: BusinessCard['status']) => {
    switch (status) {
      case 'draft':
        return 'bg-gray-100 text-gray-700';
      case 'ordered':
        return 'bg-blue-100 text-blue-700';
      case 'printing':
        return 'bg-yellow-100 text-yellow-700';
      case 'shipped':
        return 'bg-purple-100 text-purple-700';
      case 'delivered':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="mb-2">My Business Cards</h1>
            <p className="text-gray-600">Manage and order your saved card designs</p>
          </div>
          <button
            onClick={() => onNavigate('templates')}
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Create New Card
          </button>
        </div>

        {cards.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <div className="max-w-md mx-auto">
              <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Download className="size-8 text-indigo-600" />
              </div>
              <h2 className="mb-4">No Cards Yet</h2>
              <p className="text-gray-600 mb-6">
                You haven't created any business card designs yet. Start by choosing a template!
              </p>
              <button
                onClick={() => onNavigate('templates')}
                className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                Browse Templates
              </button>
            </div>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Cards List */}
            <div className="lg:col-span-2 space-y-4">
              {cards.map((card) => {
                const template = TEMPLATES.find((t) => t.id === card.templateId);
                
                return (
                  <div
                    key={card.id}
                    className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
                  >
                    <div className="flex gap-6">
                      {/* Card Preview */}
                      <div
                        className="w-48 aspect-[1.75/1] rounded-lg shadow-md flex-shrink-0 cursor-pointer"
                        style={{
                          background: `linear-gradient(135deg, ${card.customizations.primaryColor} 0%, ${card.customizations.secondaryColor} 100%)`
                        }}
                        onClick={() => setSelectedCard(card)}
                      >
                        <div className="p-4 h-full flex flex-col justify-between text-white">
                          <div>
                            <div className="w-6 h-6 bg-white/20 rounded mb-2"></div>
                            <h3 className="text-white">{card.name}</h3>
                            <p className="text-white/80">{card.title}</p>
                          </div>
                        </div>
                      </div>

                      {/* Card Details */}
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="mb-1">{card.company}</h3>
                            <p className="text-gray-600">{template?.name}</p>
                          </div>
                          <span className={`px-3 py-1 rounded-full capitalize ${getStatusColor(card.status)}`}>
                            {card.status}
                          </span>
                        </div>
                        
                        <div className="text-gray-600 mb-4">
                          <p>{card.email}</p>
                          <p>{card.phone}</p>
                          <p className="text-gray-500 mt-2">
                            Created: {new Date(card.createdAt).toLocaleDateString()}
                          </p>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-2">
                          <button
                            onClick={() => setSelectedCard(card)}
                            className="flex items-center gap-2 px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                          >
                            <Eye className="size-4" />
                            View
                          </button>
                          <button
                            onClick={() => onEditCard(card)}
                            className="flex items-center gap-2 px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          >
                            <Edit className="size-4" />
                            Edit
                          </button>
                          {card.status === 'draft' && (
                            <button
                              onClick={() => onNavigate('pricing')}
                              className="flex items-center gap-2 px-4 py-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                            >
                              <ShoppingCart className="size-4" />
                              Order
                            </button>
                          )}
                          <button
                            onClick={() => handleDelete(card.id)}
                            className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors ml-auto"
                          >
                            <Trash2 className="size-4" />
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Selected Card Details */}
            <div className="lg:sticky lg:top-24 h-fit">
              {selectedCard ? (
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h2 className="mb-6">Card Details</h2>
                  
                  {/* Front Preview */}
                  <div className="mb-4">
                    <p className="text-gray-600 mb-2">Front</p>
                    <div
                      className="aspect-[1.75/1] rounded-lg shadow-xl"
                      style={{
                        background: `linear-gradient(135deg, ${selectedCard.customizations.primaryColor} 0%, ${selectedCard.customizations.secondaryColor} 100%)`
                      }}
                    >
                      <div className="p-6 h-full flex flex-col justify-between text-white">
                        <div>
                          <div className="w-10 h-10 bg-white/20 rounded mb-3"></div>
                          <h3 className="text-white mb-1">{selectedCard.name}</h3>
                          <p className="text-white/90">{selectedCard.title}</p>
                        </div>
                        <div>
                          <p className="text-white/90">{selectedCard.company}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Back Preview */}
                  <div className="mb-6">
                    <p className="text-gray-600 mb-2">Back</p>
                    <div className="aspect-[1.75/1] rounded-lg shadow-xl bg-white border border-gray-200">
                      <div className="p-6 h-full flex flex-col justify-center">
                        <div className="space-y-2 text-gray-700">
                          <p>📧 {selectedCard.email}</p>
                          <p>📱 {selectedCard.phone}</p>
                          {selectedCard.website && <p>🌐 {selectedCard.website}</p>}
                          {selectedCard.address && <p>📍 {selectedCard.address}</p>}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Card Info */}
                  <div className="border-t border-gray-200 pt-4 space-y-3">
                    <div>
                      <p className="text-gray-600">Status</p>
                      <span className={`inline-block px-3 py-1 rounded-full capitalize ${getStatusColor(selectedCard.status)}`}>
                        {selectedCard.status}
                      </span>
                    </div>
                    <div>
                      <p className="text-gray-600">Created</p>
                      <p className="text-gray-900">
                        {new Date(selectedCard.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Template</p>
                      <p className="text-gray-900">
                        {TEMPLATES.find((t) => t.id === selectedCard.templateId)?.name}
                      </p>
                    </div>
                  </div>

                  <div className="mt-6 flex gap-3">
                    <button
                      onClick={() => onEditCard(selectedCard)}
                      className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                    >
                      Edit
                    </button>
                    {selectedCard.status === 'draft' && (
                      <button
                        onClick={() => onNavigate('pricing')}
                        className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                      >
                        Order
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-lg shadow-sm p-12 text-center">
                  <Eye className="size-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">
                    Select a card to view details
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
