import { useState, useEffect } from 'react';
import { User, TestResult } from '../App';
import { SUBJECTS } from '../data/subjects';
import { Trophy, TrendingUp, Calendar, Play, BarChart3 } from 'lucide-react';

type DashboardProps = {
  user: User | null;
  onNavigate: (page: string) => void;
  onStartTest: (subjectId: string, isFinal: boolean) => void;
};

export function Dashboard({ user, onNavigate, onStartTest }: DashboardProps) {
  const [results, setResults] = useState<TestResult[]>([]);

  useEffect(() => {
    // Load results from localStorage
    const savedResults = localStorage.getItem('ent_bridge_results');
    if (savedResults) {
      const allResults: TestResult[] = JSON.parse(savedResults);
      // Filter by current user
      const userResults = allResults.filter((r) => r.userId === user?.id);
      setResults(userResults);
    }
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <div className="text-center">
          <h2 className="mb-4">Please log in to view your dashboard</h2>
          <button
            onClick={() => onNavigate('auth')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Login
          </button>
        </div>
      </div>
    );
  }

  // Calculate statistics
  const totalTests = results.length;
  const totalScore = results.reduce((sum, r) => sum + r.score, 0);
  const totalPossible = results.reduce((sum, r) => sum + r.maxScore, 0);
  const averagePercentage = totalPossible > 0 
    ? Math.round((totalScore / totalPossible) * 100) 
    : 0;

  // Get subject performance
  const subjectPerformance = SUBJECTS.map((subject) => {
    const subjectResults = results.filter((r) => r.subjectId === subject.id);
    if (subjectResults.length === 0) return null;
    
    const avgScore = subjectResults.reduce((sum, r) => sum + r.score, 0) / subjectResults.length;
    const avgPercentage = Math.round((avgScore / subject.maxScore) * 100);
    
    return {
      subject,
      avgScore: Math.round(avgScore),
      avgPercentage,
      attempts: subjectResults.length,
    };
  }).filter(Boolean);

  const recentResults = [...results]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2">Welcome back, {user.name}! 👋</h1>
          <p className="text-gray-600">Track your progress and continue your UNT preparation</p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Trophy className="size-6 text-blue-600" />
              </div>
              <div>
                <div className="text-gray-600 mb-1">Total Tests</div>
                <div className="text-blue-600">{totalTests}</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="size-6 text-green-600" />
              </div>
              <div>
                <div className="text-gray-600 mb-1">Average Score</div>
                <div className="text-green-600">{averagePercentage}%</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="size-6 text-purple-600" />
              </div>
              <div>
                <div className="text-gray-600 mb-1">Total Points</div>
                <div className="text-purple-600">
                  {totalScore} / {totalPossible}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Subject Performance */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="mb-6">Subject Performance</h2>
            {subjectPerformance.length > 0 ? (
              <div className="space-y-4">
                {subjectPerformance.map((perf) => (
                  <div key={perf!.subject.id}>
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h3>{perf!.subject.name}</h3>
                        <p className="text-gray-600">
                          {perf!.attempts} {perf!.attempts === 1 ? 'attempt' : 'attempts'}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-blue-600">{perf!.avgPercentage}%</div>
                        <p className="text-gray-600">
                          {perf!.avgScore} / {perf!.subject.maxScore}
                        </p>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${perf!.avgPercentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-600 mb-4">No test results yet</p>
                <button
                  onClick={() => onNavigate('subjects')}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Take Your First Test
                </button>
              </div>
            )}
          </div>

          {/* Recent Tests */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="mb-6">Recent Test Results</h2>
            {recentResults.length > 0 ? (
              <div className="space-y-4">
                {recentResults.map((result) => {
                  const subject = SUBJECTS.find((s) => s.id === result.subjectId);
                  const percentage = Math.round((result.score / result.maxScore) * 100);
                  const date = new Date(result.date);
                  
                  return (
                    <div
                      key={result.id}
                      className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h3>{subject?.name}</h3>
                        <span
                          className={`px-3 py-1 rounded-full ${
                            percentage >= 70
                              ? 'bg-green-100 text-green-700'
                              : 'bg-yellow-100 text-yellow-700'
                          }`}
                        >
                          {percentage}%
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-gray-600">
                        <div className="flex items-center gap-2">
                          <Calendar className="size-4" />
                          <span>{date.toLocaleDateString()}</span>
                        </div>
                        <span>
                          {result.score} / {result.maxScore} points
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-600">No recent tests</p>
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-xl p-8">
          <h2 className="mb-4 text-white">Continue Your Preparation</h2>
          <p className="text-blue-100 mb-6">
            Choose an action to continue improving your UNT score
          </p>
          <div className="grid md:grid-cols-3 gap-4">
            <button
              onClick={() => onNavigate('subjects')}
              className="flex items-center gap-3 px-6 py-4 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
            >
              <Play className="size-5" />
              <span>Take a Test</span>
            </button>
            <button
              onClick={() => onNavigate('videos')}
              className="flex items-center gap-3 px-6 py-4 bg-blue-500 text-white rounded-lg hover:bg-blue-400 transition-colors"
            >
              <BarChart3 className="size-5" />
              <span>Video Lessons</span>
            </button>
            <button
              onClick={() => onNavigate('about')}
              className="flex items-center gap-3 px-6 py-4 bg-blue-500 text-white rounded-lg hover:bg-blue-400 transition-colors"
            >
              <TrendingUp className="size-5" />
              <span>Study Tips</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
