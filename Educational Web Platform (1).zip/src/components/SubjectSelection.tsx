import { useState } from 'react';
import { SUBJECTS } from '../data/subjects';
import { CheckCircle2, Circle, Play } from 'lucide-react';

type SubjectSelectionProps = {
  selectedSubjects: string[];
  onSubjectsChange: (subjects: string[]) => void;
  onStartTest: (subjectId: string, isFinal: boolean) => void;
  onNavigate: (page: string) => void;
};

export function SubjectSelection({
  selectedSubjects,
  onSubjectsChange,
  onStartTest,
  onNavigate,
}: SubjectSelectionProps) {
  const [localSelected, setLocalSelected] = useState<string[]>(selectedSubjects);

  const mandatorySubjects = SUBJECTS.filter((s) => s.type === 'mandatory');
  const electiveSubjects = SUBJECTS.filter((s) => s.type === 'elective');

  const selectedElectives = localSelected.filter((id) =>
    electiveSubjects.some((s) => s.id === id)
  );

  const handleElectiveToggle = (subjectId: string) => {
    if (localSelected.includes(subjectId)) {
      setLocalSelected(localSelected.filter((id) => id !== subjectId));
    } else if (selectedElectives.length < 2) {
      setLocalSelected([...localSelected, subjectId]);
    }
  };

  const handleConfirmSelection = () => {
    const allMandatory = mandatorySubjects.map((s) => s.id);
    const finalSelection = [...allMandatory, ...selectedElectives];
    onSubjectsChange(finalSelection);
  };

  const isSelectionComplete = selectedElectives.length === 2;
  const finalSelectedSubjects = [
    ...mandatorySubjects.map((s) => s.id),
    ...selectedElectives,
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="mb-4">Select Your Subjects</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Choose your subjects for the UNT exam. You must select 2 elective subjects
            in addition to the 3 mandatory subjects.
          </p>
        </div>

        {/* Mandatory Subjects */}
        <div className="mb-8">
          <h2 className="mb-4">Mandatory Subjects (3)</h2>
          <div className="grid gap-4">
            {mandatorySubjects.map((subject) => (
              <div
                key={subject.id}
                className="bg-white rounded-lg p-6 border-2 border-blue-200"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <CheckCircle2 className="size-6 text-blue-600" />
                    <div>
                      <h3>{subject.name}</h3>
                      <p className="text-gray-600">{subject.nameKz}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-blue-600">{subject.maxScore} points</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Elective Subjects */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2>Elective Subjects (Choose 2)</h2>
            <span className="text-gray-600">
              {selectedElectives.length} / 2 selected
            </span>
          </div>
          <div className="grid gap-4">
            {electiveSubjects.map((subject) => {
              const isSelected = localSelected.includes(subject.id);
              const canSelect =
                isSelected || selectedElectives.length < 2;

              return (
                <button
                  key={subject.id}
                  onClick={() => handleElectiveToggle(subject.id)}
                  disabled={!canSelect}
                  className={`bg-white rounded-lg p-6 border-2 transition-all text-left ${
                    isSelected
                      ? 'border-green-500 bg-green-50'
                      : canSelect
                      ? 'border-gray-200 hover:border-gray-300'
                      : 'border-gray-200 opacity-50 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      {isSelected ? (
                        <CheckCircle2 className="size-6 text-green-600" />
                      ) : (
                        <Circle className="size-6 text-gray-400" />
                      )}
                      <div>
                        <h3>{subject.name}</h3>
                        <p className="text-gray-600">{subject.nameKz}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span
                        className={
                          isSelected ? 'text-green-600' : 'text-gray-600'
                        }
                      >
                        {subject.maxScore} points
                      </span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Confirm Button */}
        {isSelectionComplete && (
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-center mb-6">
              <h3 className="mb-2">Your Selection is Complete!</h3>
              <p className="text-gray-600">
                Total possible score: 140 points (3 mandatory × 20 + 2 elective × 40)
              </p>
            </div>
            <button
              onClick={handleConfirmSelection}
              className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mb-4"
            >
              Confirm Selection
            </button>
          </div>
        )}

        {/* Individual Subject Tests */}
        {finalSelectedSubjects.length > 0 && (
          <div className="mt-8">
            <h2 className="mb-4">Practice Individual Subjects</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {SUBJECTS.filter((s) =>
                finalSelectedSubjects.includes(s.id)
              ).map((subject) => (
                <button
                  key={subject.id}
                  onClick={() => onStartTest(subject.id, false)}
                  className="bg-white rounded-lg p-4 border border-gray-200 hover:border-blue-300 hover:shadow-md transition-all text-left"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3>{subject.name}</h3>
                      <p className="text-gray-600">{subject.maxScore} points</p>
                    </div>
                    <Play className="size-6 text-blue-600" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Full UNT Test */}
        {isSelectionComplete && (
          <div className="mt-8">
            <div className="bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-xl p-8">
              <h2 className="mb-4 text-white">Take Full UNT Simulation</h2>
              <p className="text-blue-100 mb-6">
                Test all 5 subjects in one session to simulate the real UNT experience.
                This will take approximately 2-3 hours to complete.
              </p>
              <button
                onClick={() => onStartTest(finalSelectedSubjects[0], true)}
                className="px-6 py-3 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors flex items-center gap-2"
              >
                <Play className="size-5" />
                Start Full UNT Test
              </button>
            </div>
          </div>
        )}

        <div className="mt-6 text-center">
          <button
            onClick={() => onNavigate('home')}
            className="text-gray-600 hover:text-gray-800"
          >
            ← Back to Home
          </button>
        </div>
      </div>
    </div>
  );
}
