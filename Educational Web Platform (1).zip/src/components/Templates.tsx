import { useState } from 'react';
import { TEMPLATES } from '../data/templates';
import { Search, Filter, Star } from 'lucide-react';

type TemplatesProps = {
  onSelectTemplate: (templateId: string) => void;
  onNavigate: (page: string) => void;
};

export function Templates({ onSelectTemplate, onNavigate }: TemplatesProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Templates' },
    { id: 'modern', label: 'Modern' },
    { id: 'classic', label: 'Classic' },
    { id: 'creative', label: 'Creative' },
    { id: 'minimalist', label: 'Minimalist' },
  ];

  const filteredTemplates = TEMPLATES.filter((template) => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const popularTemplates = TEMPLATES.filter((t) => t.popular);

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="mb-4">Choose Your Template</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Select from our collection of professionally designed business card templates
          </p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search templates..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-gray-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none appearance-none bg-white"
              >
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Popular Templates */}
        {selectedCategory === 'all' && !searchTerm && (
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Star className="size-6 text-yellow-500" />
              <h2>Popular Templates</h2>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {popularTemplates.map((template) => (
                <button
                  key={template.id}
                  onClick={() => onSelectTemplate(template.id)}
                  className="group text-left"
                >
                  <div className="aspect-[1.75/1] rounded-lg shadow-lg mb-4 overflow-hidden relative hover:shadow-xl transition-shadow"
                       style={{
                         background: `linear-gradient(135deg, ${template.primaryColor} 0%, ${template.secondaryColor} 100%)`
                       }}>
                    <div className="p-6 h-full flex flex-col justify-between text-white">
                      <div>
                        <div className="w-8 h-8 bg-white/20 rounded mb-3"></div>
                        <h3 className="text-white">Your Name</h3>
                        <p className="text-white/80">Your Title</p>
                      </div>
                      <div className="text-white/90">
                        <p>email@example.com</p>
                        <p>+1 (555) 123-4567</p>
                      </div>
                    </div>
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="text-white px-6 py-3 bg-indigo-600 rounded-lg">
                        Use This Template
                      </span>
                    </div>
                  </div>
                  <h3>{template.name}</h3>
                  <p className="text-gray-600">{template.description}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* All Templates */}
        <div>
          <h2 className="mb-6">
            {selectedCategory === 'all' ? 'All Templates' : `${categories.find(c => c.id === selectedCategory)?.label} Templates`}
          </h2>
          
          {filteredTemplates.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTemplates.map((template) => (
                <button
                  key={template.id}
                  onClick={() => onSelectTemplate(template.id)}
                  className="group text-left"
                >
                  <div className="aspect-[1.75/1] rounded-lg shadow-lg mb-4 overflow-hidden relative hover:shadow-xl transition-shadow"
                       style={{
                         background: `linear-gradient(135deg, ${template.primaryColor} 0%, ${template.secondaryColor} 100%)`
                       }}>
                    <div className="p-6 h-full flex flex-col justify-between text-white">
                      <div>
                        <div className="w-8 h-8 bg-white/20 rounded mb-3"></div>
                        <h3 className="text-white">Your Name</h3>
                        <p className="text-white/80">Your Title</p>
                      </div>
                      <div className="text-white/90">
                        <p>email@example.com</p>
                        <p>+1 (555) 123-4567</p>
                      </div>
                    </div>
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="text-white px-6 py-3 bg-indigo-600 rounded-lg">
                        Use This Template
                      </span>
                    </div>
                    {template.popular && (
                      <div className="absolute top-4 right-4 bg-yellow-500 text-white px-3 py-1 rounded-full flex items-center gap-1">
                        <Star className="size-4" />
                        <span>Popular</span>
                      </div>
                    )}
                  </div>
                  <h3>{template.name}</h3>
                  <p className="text-gray-600">{template.description}</p>
                  <div className="mt-2">
                    <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full capitalize">
                      {template.category}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg">
              <p className="text-gray-600 mb-4">No templates found matching your criteria</p>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('all');
                }}
                className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
