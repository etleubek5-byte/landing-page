import { Subject, Question, User, TestResult, Homework, VideoLesson } from '../types';

// Mock subjects data
export const subjects: Subject[] = [
  // Mandatory subjects
  {
    id: 'history-kz',
    name: 'История Казахстана',
    isMandatory: true,
    maxScore: 25,
  },
  {
    id: 'math-literacy',
    name: 'Математическая грамотность',
    isMandatory: true,
    maxScore: 20,
  },
  {
    id: 'reading-literacy',
    name: 'Грамотность чтения',
    isMandatory: true,
    maxScore: 20,
  },
  // Elective subjects - Natural Sciences
  {
    id: 'physics',
    name: 'Физика',
    isMandatory: false,
    category: 'natural-sciences',
    maxScore: 40,
  },
  {
    id: 'chemistry',
    name: 'Химия',
    isMandatory: false,
    category: 'natural-sciences',
    maxScore: 40,
  },
  {
    id: 'biology',
    name: 'Биология',
    isMandatory: false,
    category: 'natural-sciences',
    maxScore: 40,
  },
  // Elective subjects - Social Sciences
  {
    id: 'world-history',
    name: 'Всемирная история',
    isMandatory: false,
    category: 'social-sciences',
    maxScore: 40,
  },
  {
    id: 'geography',
    name: 'География',
    isMandatory: false,
    category: 'social-sciences',
    maxScore: 40,
  },
  {
    id: 'english',
    name: 'Английский язык',
    isMandatory: false,
    category: 'social-sciences',
    maxScore: 40,
  },
  // Elective subjects - Creative
  {
    id: 'creative-exam',
    name: 'Творческий экзамен',
    isMandatory: false,
    category: 'creative',
    maxScore: 40,
  },
];

// Mock questions for each subject
export const questions: Question[] = [
  // History of Kazakhstan
  {
    id: 'hk-1',
    subjectId: 'history-kz',
    question: 'В каком году была принята Декларация о государственном суверенитете Казахстана?',
    options: ['1989', '1990', '1991', '1992'],
    correctAnswer: 1,
    difficulty: 'medium',
  },
  {
    id: 'hk-2',
    subjectId: 'history-kz',
    question: 'Кто был первым Президентом Республики Казахстан?',
    options: ['Динмухамед Кунаев', 'Нурсултан Назарбаев', 'Касым-Жомарт Токаев', 'Серикболсын Абдильдин'],
    correctAnswer: 1,
    difficulty: 'easy',
  },
  {
    id: 'hk-3',
    subjectId: 'history-kz',
    question: 'Какой город был столицей Казахстана до Астаны?',
    options: ['Шымкент', 'Караганда', 'Алматы', 'Актобе'],
    correctAnswer: 2,
    difficulty: 'easy',
  },
  {
    id: 'hk-4',
    subjectId: 'history-kz',
    question: 'В каком году столица была перенесена из Алматы в Астану?',
    options: ['1995', '1997', '1998', '2000'],
    correctAnswer: 1,
    difficulty: 'medium',
  },
  {
    id: 'hk-5',
    subjectId: 'history-kz',
    question: 'Какой древний город на территории Казахстана был важным пунктом на Великом Шелковом пути?',
    options: ['Отрар', 'Павлодар', 'Петропавловск', 'Кызылорда'],
    correctAnswer: 0,
    difficulty: 'hard',
  },

  // Mathematical Literacy
  {
    id: 'ml-1',
    subjectId: 'math-literacy',
    question: 'Если 25% от числа равно 50, чему равно это число?',
    options: ['100', '150', '200', '250'],
    correctAnswer: 2,
    difficulty: 'easy',
  },
  {
    id: 'ml-2',
    subjectId: 'math-literacy',
    question: 'В магазине скидка 20% на товар стоимостью 5000 тенге. Какова окончательная цена?',
    options: ['4500 тенге', '4000 тенге', '3500 тенге', '3000 тенге'],
    correctAnswer: 1,
    difficulty: 'easy',
  },
  {
    id: 'ml-3',
    subjectId: 'math-literacy',
    question: 'Площадь прямоугольника равна 48 см². Если длина равна 8 см, чему равна ширина?',
    options: ['4 см', '5 см', '6 см', '7 см'],
    correctAnswer: 2,
    difficulty: 'medium',
  },
  {
    id: 'ml-4',
    subjectId: 'math-literacy',
    question: 'За 3 часа автомобиль проехал 240 км. Какова средняя скорость?',
    options: ['60 км/ч', '70 км/ч', '80 км/ч', '90 км/ч'],
    correctAnswer: 2,
    difficulty: 'easy',
  },
  {
    id: 'ml-5',
    subjectId: 'math-literacy',
    question: 'Если x + 7 = 15, чему равно x?',
    options: ['6', '7', '8', '9'],
    correctAnswer: 2,
    difficulty: 'easy',
  },

  // Reading Literacy
  {
    id: 'rl-1',
    subjectId: 'reading-literacy',
    question: 'Какой жанр литературы характеризуется наличием вымышленных персонажей и событий?',
    options: ['Документальная проза', 'Художественная литература', 'Научная статья', 'Биография'],
    correctAnswer: 1,
    difficulty: 'easy',
  },
  {
    id: 'rl-2',
    subjectId: 'reading-literacy',
    question: 'Что означает термин "аллегория" в литературе?',
    options: ['Повторение звуков', 'Скрытый смысл через образы', 'Прямое сравнение', 'Описание природы'],
    correctAnswer: 1,
    difficulty: 'medium',
  },
  {
    id: 'rl-3',
    subjectId: 'reading-literacy',
    question: 'Кто написал роман "Путь Абая"?',
    options: ['Мухтар Ауэзов', 'Абай Кунанбаев', 'Ильяс Есенберлин', 'Мухтар Шаханов'],
    correctAnswer: 0,
    difficulty: 'medium',
  },
  {
    id: 'rl-4',
    subjectId: 'reading-literacy',
    question: 'Какой литературный прием использует сравнение с использованием слов "как" или "словно"?',
    options: ['Метафора', 'Сравнение', 'Гипербола', 'Олицетворение'],
    correctAnswer: 1,
    difficulty: 'easy',
  },
  {
    id: 'rl-5',
    subjectId: 'reading-literacy',
    question: 'Основная идея текста называется:',
    options: ['Тема', 'Сюжет', 'Композиция', 'Стиль'],
    correctAnswer: 0,
    difficulty: 'easy',
  },

  // Physics
  {
    id: 'ph-1',
    subjectId: 'physics',
    question: 'Какова единица измерения силы в системе СИ?',
    options: ['Джоуль', 'Ньютон', 'Ватт', 'Паскаль'],
    correctAnswer: 1,
    difficulty: 'easy',
  },
  {
    id: 'ph-2',
    subjectId: 'physics',
    question: 'Скорость света в вакууме приблизительно равна:',
    options: ['300 000 м/с', '300 000 км/с', '30 000 км/с', '3 000 000 км/с'],
    correctAnswer: 1,
    difficulty: 'medium',
  },
  {
    id: 'ph-3',
    subjectId: 'physics',
    question: 'Первый закон Ньютона также называется законом:',
    options: ['Движения', 'Инерции', 'Действия', 'Гравитации'],
    correctAnswer: 1,
    difficulty: 'medium',
  },
  {
    id: 'ph-4',
    subjectId: 'physics',
    question: 'Какой тип энергии обладает движущееся тело?',
    options: ['Потенциальная', 'Кинетическая', 'Тепловая', 'Химическая'],
    correctAnswer: 1,
    difficulty: 'easy',
  },
  {
    id: 'ph-5',
    subjectId: 'physics',
    question: 'При какой температуре вода замерзает по шкале Цельсия?',
    options: ['-10°C', '0°C', '10°C', '32°C'],
    correctAnswer: 1,
    difficulty: 'easy',
  },

  // Chemistry
  {
    id: 'ch-1',
    subjectId: 'chemistry',
    question: 'Какой химический символ у золота?',
    options: ['Go', 'Gd', 'Au', 'Ag'],
    correctAnswer: 2,
    difficulty: 'easy',
  },
  {
    id: 'ch-2',
    subjectId: 'chemistry',
    question: 'Сколько протонов содержится в атоме углерода?',
    options: ['4', '6', '8', '12'],
    correctAnswer: 1,
    difficulty: 'medium',
  },
  {
    id: 'ch-3',
    subjectId: 'chemistry',
    question: 'Какая формула у воды?',
    options: ['H2O', 'CO2', 'O2', 'H2O2'],
    correctAnswer: 0,
    difficulty: 'easy',
  },
  {
    id: 'ch-4',
    subjectId: 'chemistry',
    question: 'pH нейтрального раствора равен:',
    options: ['0', '7', '14', '1'],
    correctAnswer: 1,
    difficulty: 'easy',
  },
  {
    id: 'ch-5',
    subjectId: 'chemistry',
    question: 'Какой газ выделяется при реакции кислоты с металлом?',
    options: ['Кислород', 'Азот', 'Водород', 'Углекислый газ'],
    correctAnswer: 2,
    difficulty: 'medium',
  },

  // Biology
  {
    id: 'bi-1',
    subjectId: 'biology',
    question: 'Какая часть клетки содержит генетическую информацию?',
    options: ['Цитоплазма', 'Мембрана', 'Ядро', 'Митохондрия'],
    correctAnswer: 2,
    difficulty: 'easy',
  },
  {
    id: 'bi-2',
    subjectId: 'biology',
    question: 'Процесс, при котором растения производят пищу, называется:',
    options: ['Дыхание', 'Фотосинтез', 'Метаболизм', 'Ферментация'],
    correctAnswer: 1,
    difficulty: 'easy',
  },
  {
    id: 'bi-3',
    subjectId: 'biology',
    question: 'Сколько хромосом содержится в нормальной клетке человека?',
    options: ['23', '46', '48', '92'],
    correctAnswer: 1,
    difficulty: 'medium',
  },
  {
    id: 'bi-4',
    subjectId: 'biology',
    question: 'Какой орган человека отвечает за фильтрацию крови?',
    options: ['Печень', 'Почки', 'Сердце', 'Легкие'],
    correctAnswer: 1,
    difficulty: 'easy',
  },
  {
    id: 'bi-5',
    subjectId: 'biology',
    question: 'ДНК расшифровывается как:',
    options: ['Дезоксирибонуклеиновая кислота', 'Динитронуклеиновая кислота', 'Дихлорнуклеиновая кислота', 'Диметилнуклеиновая кислота'],
    correctAnswer: 0,
    difficulty: 'medium',
  },
];

// Mock users
export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Айгуль Сарсенова',
    email: 'aigul@example.com',
    username: 'aigul_student',
    isAdmin: false,
    createdAt: new Date('2024-09-01'),
  },
  {
    id: '2',
    name: 'Администратор',
    email: 'admin@entbridge.kz',
    username: 'admin',
    isAdmin: true,
    createdAt: new Date('2024-01-01'),
  },
];

// Mock test results
export const mockTestResults: TestResult[] = [
  {
    id: 'result-1',
    userId: '1',
    subjectId: 'history-kz',
    subjectName: 'История Казахстана',
    score: 20,
    maxScore: 25,
    totalQuestions: 5,
    correctAnswers: 4,
    date: new Date('2024-10-15'),
    answers: [],
  },
  {
    id: 'result-2',
    userId: '1',
    subjectId: 'math-literacy',
    subjectName: 'Математическая грамотность',
    score: 16,
    maxScore: 20,
    totalQuestions: 5,
    correctAnswers: 4,
    date: new Date('2024-10-18'),
    answers: [],
  },
  {
    id: 'result-3',
    userId: '1',
    subjectId: 'physics',
    subjectName: 'Физика',
    score: 32,
    maxScore: 40,
    totalQuestions: 5,
    correctAnswers: 4,
    date: new Date('2024-10-20'),
    answers: [],
  },
];

// Mock homework
export const mockHomework: Homework[] = [
  {
    id: 'hw-1',
    title: 'Эссе о независимости Казахстана',
    description: 'Напишите эссе объемом 300-500 слов о значении независимости Казахстана.',
    subjectId: 'history-kz',
    dueDate: new Date('2024-11-15'),
    assignedBy: 'admin',
    submissions: [],
  },
  {
    id: 'hw-2',
    title: 'Решение задач по физике',
    description: 'Решите задачи 1-10 из главы "Механика".',
    subjectId: 'physics',
    dueDate: new Date('2024-11-20'),
    assignedBy: 'admin',
    submissions: [],
  },
];

// Mock video lessons
export const mockVideoLessons: VideoLesson[] = [
  {
    id: 'vid-1',
    title: 'История независимости Казахстана',
    subjectId: 'history-kz',
    youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg',
    duration: '25:30',
    description: 'Подробный урок о пути Казахстана к независимости',
  },
  {
    id: 'vid-2',
    title: 'Проценты и их применение',
    subjectId: 'math-literacy',
    youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg',
    duration: '18:45',
    description: 'Как решать задачи с процентами',
  },
  {
    id: 'vid-3',
    title: 'Законы Ньютона',
    subjectId: 'physics',
    youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg',
    duration: '30:15',
    description: 'Три закона Ньютона с примерами',
  },
  {
    id: 'vid-4',
    title: 'Периодическая таблица элементов',
    subjectId: 'chemistry',
    youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg',
    duration: '22:00',
    description: 'Структура и использование периодической таблицы',
  },
  {
    id: 'vid-5',
    title: 'Строение клетки',
    subjectId: 'biology',
    youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg',
    duration: '20:30',
    description: 'Органеллы клетки и их функции',
  },
];
